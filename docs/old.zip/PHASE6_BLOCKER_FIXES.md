# Phase 6 Blocker Resolution Guide

Two blockers prevent Burn model inference in WASM. Both are fixable.

---

## Blocker 1: ONNX Opset Mismatch

**Problem:** `burn-import` requires opset 13+, but `bge-small-en-v1.5` ONNX is opset 11.

### Solution: Convert to Opset 13

**Option A: Python conversion (recommended)**

```bash
# Install dependencies
pip install onnx onnxruntime

# Create conversion script
cat > convert_opset.py << 'EOF'
import onnx
from onnx import version_converter

# Load opset 11 model
model = onnx.load("models/bge-small-en-v1.5.onnx")
print(f"Original opset: {model.opset_import[0].version}")

# Convert to opset 13
converted = version_converter.convert_version(model, 13)
print(f"Converted opset: {converted.opset_import[0].version}")

# Validate
onnx.checker.check_model(converted)

# Save
onnx.save(converted, "models/bge-small-en-v1.5-opset13.onnx")
print("Saved: models/bge-small-en-v1.5-opset13.onnx")
EOF

python convert_opset.py
```

**Option B: Export fresh from PyTorch (if conversion fails)**

```bash
pip install transformers torch onnx

cat > export_model.py << 'EOF'
from transformers import AutoModel, AutoTokenizer
import torch

model_name = "BAAI/bge-small-en-v1.5"
model = AutoModel.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)

model.eval()

# Dummy input
dummy = tokenizer("hello world", return_tensors="pt", padding=True, truncation=True)

# Export with opset 13
torch.onnx.export(
    model,
    (dummy["input_ids"], dummy["attention_mask"]),
    "models/bge-small-en-v1.5-opset13.onnx",
    input_names=["input_ids", "attention_mask"],
    output_names=["last_hidden_state"],
    dynamic_axes={
        "input_ids": {0: "batch", 1: "seq"},
        "attention_mask": {0: "batch", 1: "seq"},
        "last_hidden_state": {0: "batch", 1: "seq"}
    },
    opset_version=13,
    do_constant_folding=True
)
print("Exported with opset 13")
EOF

python export_model.py
```

**Update build.rs:**

```rust
// Change download URL or use local converted model
const MODEL_URL: &str = "file://models/bge-small-en-v1.5-opset13.onnx";
// Or host on your CDN after conversion
```

**Verification:**

```bash
# Check opset version
python -c "import onnx; m = onnx.load('models/bge-small-en-v1.5-opset13.onnx'); print(f'Opset: {m.opset_import[0].version}')"
# Should print: Opset: 13

# Test burn-import
cd ingestor-wasm && cargo build 2>&1 | grep -i opset
# Should not show opset errors
```

---

## Blocker 2: Tokenizer WASM Incompatibility

**Problem:** `tokenizers` crate depends on `onig` (C library), which doesn't compile to WASM.

### Solution A: Use `tokenizers` with WASM feature (Recommended)

The `tokenizers` crate actually has WASM support, but you need the right features:

```toml
# Cargo.toml
[dependencies]
tokenizers = { version = "0.20", default-features = false, features = ["unstable_wasm"] }
```

**Note:** This is marked "unstable" but works. It uses a pure-Rust regex fallback instead of `onig`.

**If that fails, try:**

```toml
# Disable ALL optional features
tokenizers = { version = "0.20", default-features = false }
```

Then in code, handle the reduced functionality:

```rust
use tokenizers::Tokenizer;

// Load from JSON (this works in WASM)
let tokenizer = Tokenizer::from_bytes(include_bytes!("tokenizer.json"))
    .expect("Failed to load tokenizer");

// Encode (works)
let encoding = tokenizer.encode("hello world", false).unwrap();
let input_ids = encoding.get_ids();
let attention_mask = encoding.get_attention_mask();
```

### Solution B: Pure Rust WordPiece (Fallback)

If `tokenizers` still fails, implement minimal WordPiece:

```rust
use std::collections::HashMap;

pub struct SimpleWordPieceTokenizer {
    vocab: HashMap<String, u32>,
    unk_token_id: u32,
    cls_token_id: u32,
    sep_token_id: u32,
    pad_token_id: u32,
}

impl SimpleWordPieceTokenizer {
    pub fn from_vocab_json(json_bytes: &[u8]) -> Self {
        let vocab: HashMap<String, u32> = serde_json::from_slice(json_bytes).unwrap();
        Self {
            unk_token_id: vocab["[UNK]"],
            cls_token_id: vocab["[CLS]"],
            sep_token_id: vocab["[SEP]"],
            pad_token_id: vocab["[PAD]"],
            vocab,
        }
    }

    pub fn encode(&self, text: &str, max_length: usize) -> (Vec<u32>, Vec<u32>) {
        let mut input_ids = vec![self.cls_token_id];
        let mut attention_mask = vec![1u32];

        // Simple whitespace + lowercase tokenization
        for word in text.to_lowercase().split_whitespace() {
            let token_id = self.tokenize_word(word);
            if input_ids.len() < max_length - 1 {
                input_ids.push(token_id);
                attention_mask.push(1);
            }
        }

        // Add [SEP]
        input_ids.push(self.sep_token_id);
        attention_mask.push(1);

        // Pad to max_length
        while input_ids.len() < max_length {
            input_ids.push(self.pad_token_id);
            attention_mask.push(0);
        }

        (input_ids, attention_mask)
    }

    fn tokenize_word(&self, word: &str) -> u32 {
        // Try whole word first
        if let Some(&id) = self.vocab.get(word) {
            return id;
        }

        // Try WordPiece subwords
        let mut start = 0;
        while start < word.len() {
            let mut end = word.len();
            let mut found = false;

            while start < end {
                let substr = if start == 0 {
                    &word[start..end]
                } else {
                    &format!("##{}", &word[start..end])
                };

                if self.vocab.contains_key(substr) {
                    found = true;
                    break;
                }
                end -= 1;
            }

            if !found {
                return self.unk_token_id;
            }
            start = end;
        }

        self.unk_token_id // Simplified - real impl would collect subword IDs
    }
}
```

**Note:** This is a simplified implementation. For production, use the `tokenizers` crate with WASM features.

### Solution C: JavaScript Tokenizer Bridge (Last Resort)

If Rust tokenization completely fails, use transformers.js on the JS side:

```javascript
// In JavaScript
import { AutoTokenizer } from '@xenova/transformers';

const tokenizer = await AutoTokenizer.from_pretrained('BAAI/bge-small-en-v1.5');

export function tokenize(text) {
    const { input_ids, attention_mask } = tokenizer(text, {
        padding: true,
        truncation: true,
        max_length: 512
    });
    return { input_ids: Array.from(input_ids.data), attention_mask: Array.from(attention_mask.data) };
}
```

```rust
// In Rust, receive pre-tokenized input
#[wasm_bindgen]
impl Embedder {
    pub fn embed_tokenized(&self, input_ids: Vec<i64>, attention_mask: Vec<i64>) -> Vec<f32> {
        // Skip tokenization, go straight to model inference
        self.forward(input_ids, attention_mask)
    }
}
```

**Trade-off:** Adds JS dependency, but guarantees compatibility.

---

## Verification Checklist

After applying fixes:

```bash
# 1. Verify ONNX opset
python -c "import onnx; m = onnx.load('models/bge-small-en-v1.5-opset13.onnx'); print(m.opset_import[0].version)"
# Expected: 13

# 2. Test burn-import in build
cd ingestor-wasm
cargo build 2>&1 | head -50
# Expected: No opset errors, model code generated in src/model/

# 3. Test WASM compilation
wasm-pack build --target web --dev 2>&1 | tail -20
# Expected: Successful build

# 4. Test tokenizer in WASM
# Create a simple test that loads tokenizer and encodes text
cargo test --target wasm32-unknown-unknown tokenizer_works
```

---

## Updated build.rs

After conversion, update `build.rs`:

```rust
use std::path::Path;
use std::fs;

fn main() {
    let model_path = Path::new("models/bge-small-en-v1.5-opset13.onnx");
    
    // Download if not exists (use converted model URL)
    if !model_path.exists() {
        println!("cargo:warning=Model not found. Please run: python convert_opset.py");
        println!("cargo:warning=Or download pre-converted model from your CDN");
        return;
    }

    // Generate Burn model code
    burn_import::onnx::ModelGen::new()
        .input(model_path.to_str().unwrap())
        .out_dir("src/model/")
        .run_from_script();
        
    println!("cargo:rerun-if-changed=models/bge-small-en-v1.5-opset13.onnx");
}
```

---

## Timeline

| Task | Time | Priority |
|------|------|----------|
| Convert ONNX to opset 13 | 30 min | Critical |
| Test burn-import | 15 min | Critical |
| Fix tokenizer features | 30 min | Critical |
| Test WASM build | 30 min | High |
| Complete forward pass | 2 hours | High |
| Browser testing | 2 hours | Medium |

**Total: ~6 hours of focused work**

---

## Quick Start

```bash
# 1. Convert model
cd /path/to/llmx/ingestor-wasm
pip install onnx
python -c "
import onnx
from onnx import version_converter
m = onnx.load('models/bge-small-en-v1.5.onnx')
c = version_converter.convert_version(m, 13)
onnx.save(c, 'models/bge-small-en-v1.5-opset13.onnx')
print('Done')
"

# 2. Update Cargo.toml tokenizer line
# tokenizers = { version = "0.20", default-features = false, features = ["unstable_wasm"] }

# 3. Update build.rs to use opset13 model

# 4. Build
cargo build --package ingestor-wasm

# 5. If model code generated, uncomment embeddings_burn.rs model imports

# 6. Build WASM
wasm-pack build --target web --release
```

---

## If All Else Fails: Pivot to Transformers.js

If Burn + WASM remains too painful, consider using Transformers.js directly:

```javascript
import { pipeline } from '@xenova/transformers';

const embedder = await pipeline('feature-extraction', 'Xenova/bge-small-en-v1.5', {
    device: 'webgpu'  // Uses WebGPU when available
});

const embedding = await embedder('text to embed', { pooling: 'mean', normalize: true });
```

This is battle-tested, but moves embedding logic to JS. Your Rust code would receive embeddings rather than generating them.

**Trade-off:** Less Rust purity, but guaranteed to work in browser with WebGPU.
