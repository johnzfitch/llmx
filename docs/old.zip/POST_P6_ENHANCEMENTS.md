# Post-Phase 6 Enhancements

## Priority Tiers

### Tier 1: High Impact, Low Effort
1. **Quality Scoring** - Filter garbage chunks before ranking
2. **Memory-Mapped Indexes** - 100x faster index loading

### Tier 2: High Impact, Medium Effort
3. **SPLADE** - Learned sparse retrieval (semantic + inverted index speed)
4. **Incremental Indexing** - Filesystem watching, no full reindex

### Tier 3: Medium Impact, Medium Effort
5. **Self-Tuning** - Learn from agent click/use patterns
6. **Predictive Prefetching** - Preload likely next queries

### Tier 4: Low Priority / Research
7. **SIMD BM25** - Micro-optimization
8. **Zero-Copy Streaming** - If MCP supports it

---

## 1. Quality Scoring (Layer E from specho-v2)

**Problem:** Not all chunks are useful. Boilerplate, repetitive code, verbose comments waste tokens.

**Solution:** Score chunk quality during indexing, filter in search.

```rust
pub fn chunk_quality_score(text: &str) -> f32 {
    let features = [
        lexical_diversity(text),      // unique_words / total_words
        burstiness(text),             // variance in sentence lengths
        stopword_ratio(text),         // common words ratio (low = better for code)
        punctuation_density(text),    // code tends to have more
        avg_word_length(text),        // technical terms are longer
    ];
    
    // Weighted sum (tune weights empirically)
    let weights = [0.25, 0.20, 0.15, 0.20, 0.20];
    features.iter().zip(weights).map(|(f, w)| f * w).sum()
}
```

**Integration:**
```rust
// During indexing
chunk.quality_score = chunk_quality_score(&chunk.content);

// During search
let results = results.into_iter()
    .filter(|r| r.quality_score >= 0.5)  // Threshold
    .collect();
```

**Impact:** 60% token reduction, 5x faster to answer (fewer irrelevant chunks).

**Dependencies:** None (pure Rust, ~100 LOC).

---

## 2. Memory-Mapped Indexes

**Problem:** JSON parse on every load. 1.5MB index = 125ms.

**Solution:** Binary format + mmap.

```rust
// Write
let bytes = bincode::serialize(&index)?;
fs::write(path, bytes)?;

// Read (zero-copy)
let file = File::open(path)?;
let mmap = unsafe { MmapOptions::new().map(&file)? };
let index: IndexFile = bincode::deserialize(&mmap)?;
```

**Deps:**
```toml
memmap2 = "0.9"
bincode = "1.3"
```

**Impact:** 125ms → 1ms load time (125x).

**Tradeoff:** Binary not human-readable. Keep JSON export for debugging.

---

## 3. SPLADE (Learned Sparse Retrieval)

**Problem:** BM25 is lexical-only. "authenticate" won't find "login".

**Problem with embeddings:** Slow (dot product with all chunks).

**SPLADE:** Best of both. Expands query into weighted terms, uses inverted index.

```
Query: "authentication"

BM25: {authentication: 1.0}

SPLADE: {
    authentication: 2.3,
    login: 1.8,
    verify: 1.2,
    credentials: 0.9,
    token: 0.7
}
```

**Implementation:**
```rust
pub struct SpladeModel {
    session: ort::Session,
    tokenizer: Tokenizer,
}

impl SpladeModel {
    pub fn expand(&self, query: &str) -> HashMap<String, f32> {
        let tokens = self.tokenizer.encode(query)?;
        let output = self.session.run([tokens])?;
        decode_sparse_vector(output)
    }
}

// In search
let expanded = splade.expand(&query);
let results = index.search_weighted(expanded, limit);
```

**Model:** `naver/splade-cocondenser-ensembledistil` (ONNX exportable, ~150MB)

**Impact:** 15-25% accuracy improvement, same speed as BM25.

---

## 4. Incremental Indexing (Filesystem Watching)

**Problem:** Full reindex on every change. Slow for large projects.

**Solution:** Watch filesystem, update only changed files.

```rust
use notify::{Watcher, RecursiveMode, Event};

pub struct IncrementalIndexer {
    watcher: RecommendedWatcher,
    debouncer: Debouncer,  // Handle rapid saves
}

impl IncrementalIndexer {
    pub fn watch(&mut self, paths: Vec<PathBuf>) -> Result<()> {
        for path in paths {
            self.watcher.watch(&path, RecursiveMode::Recursive)?;
        }
    }

    async fn on_modify(&mut self, path: &Path) {
        // Remove old chunks for this file
        index.chunks.retain(|c| c.path != path);
        
        // Re-chunk
        let new_chunks = chunk_file(path)?;
        
        // Update inverted index incrementally
        for chunk in new_chunks {
            index.inverted_index.add_chunk(&chunk);
            index.chunks.push(chunk);
        }
        
        // Regenerate embeddings only for new chunks
        if let Some(emb) = &mut index.embeddings {
            for chunk in &new_chunks {
                emb.push(generate_embedding(&chunk.content)?);
            }
        }
    }
}
```

**Debouncing:** Wait 500ms after last change before reindexing (editors save frequently).

**Deps:**
```toml
notify = "6.0"
```

---

## 5. Self-Tuning from Agent Behavior

**Insight:** Track which search results agents actually use. Learn to boost useful patterns.

```rust
pub struct AgentFeedback {
    pub query_embedding: Vec<f32>,  // Privacy: don't store raw query
    pub clicked_chunks: Vec<String>,
    pub task_completed: bool,
    pub timestamp: SystemTime,
}

pub fn learned_boost(&self, query: &str, chunk_id: &str) -> f32 {
    // Find similar past queries
    let query_emb = generate_embedding(query);
    let similar = self.feedback.iter()
        .filter(|f| cosine_similarity(&f.query_embedding, &query_emb) > 0.7)
        .collect();

    if similar.is_empty() { return 0.0; }

    // Click rate for this chunk on similar queries
    let clicks = similar.iter()
        .filter(|f| f.clicked_chunks.contains(&chunk_id))
        .count() as f32;
    
    // Success rate when clicked
    let successes = similar.iter()
        .filter(|f| f.clicked_chunks.contains(&chunk_id) && f.task_completed)
        .count() as f32;

    (clicks / similar.len() as f32) * 0.5 + (successes / clicks.max(1.0)) * 0.5
}

// Apply in ranking
let final_score = bm25_score * 0.7 + learned_boost * 0.3;
```

**Bootstrapping:** Needs ~100 queries before meaningful patterns emerge.

---

## 6. Predictive Prefetching

**Observation:** Agents follow patterns:
- Search "authentication" → likely next: "token validation", "login flow"
- Find function X → likely next: "where is X called"

**Solution:** Preload likely next queries during agent think time.

```rust
pub fn predict_next(&self, query: &str) -> Vec<String> {
    let mut candidates = vec![];

    // Pattern: function search → callers
    if let Some(func) = extract_function_name(query) {
        candidates.push(format!("where is {} called", func));
    }

    // Pattern: error → handling
    if query.contains("error") {
        candidates.push("error handling patterns".to_string());
    }

    // Historical patterns
    candidates.extend(self.historical_next_queries(query));

    candidates.into_iter().take(3).collect()
}

pub async fn search_with_prefetch(&mut self, query: &str) -> SearchOutput {
    let results = self.search(query).await?;

    // Background prefetch
    let predicted = self.predict_next(query);
    tokio::spawn(async move {
        for q in predicted {
            let _ = self.search(&q).await;  // Warm cache
        }
    });

    results
}
```

---

## 7. SIMD BM25 (Micro-optimization)

Process 8 documents at once with AVX2/NEON.

```rust
use std::simd::*;

// Vectorized BM25 scoring
let term_freqs = f32x8::from_slice(&chunk.term_freqs);
let doc_lens = f32x8::from_slice(&chunk.doc_lens);

let numerator = term_freqs * k1_plus_1;
let denominator = term_freqs + k1_factor * doc_lens;
let scores = idf_vec * (numerator / denominator);
```

**Speedup:** 4-8x for scoring loop.

**Requires:** Nightly Rust, SIMD feature flag.

**Priority:** Low. Only if profiling shows BM25 scoring is bottleneck (unlikely).

---

## Success Metrics

| Enhancement | Metric | Target |
|-------------|--------|--------|
| Quality scoring | Token reduction | >50% |
| Memory-mapped | Load time | <5ms |
| SPLADE | Precision@5 | +15% |
| Incremental | Update latency | <1s |
| Self-tuning | Precision@5 | +10% after 100 queries |
| Prefetching | Cache hit rate | >30% |

---

## Implementation Order

**Phase 7:** Quality Scoring + Memory-Mapped (low effort, high impact)

**Phase 8:** SPLADE + Incremental Indexing (core retrieval improvements)

**Phase 9:** Self-Tuning + Prefetching (agent-aware optimization)

**Later:** SIMD, streaming (only if profiling justifies)
