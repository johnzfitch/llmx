# llmx MCP Tool Surface: Spec-Compliant Redesign

Status: architectural analysis
Updated: 2026-03-14
Against: MCP draft spec (2025-11-25+), review of `06-MCP-Tools/` corpus
Scope: all llmx MCP tools, server capabilities, lifecycle, and agent utility

## Executive Summary

The "Recursive Code Environment" document raises a genuine architectural insight: llmx
should be instantly useful before full indexing completes. But the framing oversells this
as a paradigm shift when it's actually a well-understood engineering pattern (lazy
materialization with background precomputation). The citations (MIT CSAIL "Recursive
Language Models" paper, "CodeRLM", "Codified Context") are unverifiable — I can't find
these papers or products.

What IS real and actionable:

1. **Tiered readiness** — the MCP server should be useful at Tier 0 (file manifest)
   within milliseconds, not block on full indexing.
2. **Filesystem watching** — the server is long-running; it should maintain index
   freshness via inotify/fanotify.
3. **The agent loop IS the retrieval strategy** — the tools need to be composable
   enough that agents can chain them effectively.

What the document misses entirely: **the MCP spec itself provides mechanisms
(capabilities, resources, notifications, progress, tasks) that llmx should be using
and isn't.** The real redesign isn't about "index vs. environment" — it's about
being a proper MCP citizen.

This document redesigns every llmx MCP tool against the actual spec.

---

## Part 1: Server-Level MCP Compliance

### 1.1 Capability Declaration

The llmx MCP server must declare capabilities during `initialize`:

```json
{
  "protocolVersion": "2025-11-25",
  "capabilities": {
    "tools": {
      "listChanged": true
    },
    "resources": {
      "subscribe": true,
      "listChanged": true
    },
    "tasks": {
      "list": {},
      "cancel": {},
      "requests": {
        "tools": {
          "call": {}
        }
      }
    },
    "logging": {}
  },
  "serverInfo": {
    "name": "llmx",
    "title": "llmx Code Intelligence",
    "version": "0.2.0",
    "description": "Structural code search, symbol resolution, and graph traversal for agent workflows."
  }
}
```

**Why `tools.listChanged: true`**: As background indexing completes, new tools may become
available or existing tools may gain richer capabilities. The server should emit
`notifications/tools/list_changed` when, e.g., a tool transitions from "text search only"
to "structural search available."

**Why `resources`**: Source files, index metadata, and the symbol table should be
exposed as MCP resources. This lets clients subscribe to file changes and lets tool
results return `resource_link` items instead of inlining entire source files.

**Why `tasks`**: Full re-indexing (`llmx_index`) and large graph walks can take seconds
to minutes. Task support lets the client poll for completion instead of blocking.

**Why `logging`**: The server should emit structured logs during indexing and query
execution. The spec supports this via `notifications/message` with severity levels.

### 1.2 Roots Integration

llmx should use the MCP `roots/list` request (server → client) to discover project
directories instead of requiring explicit `--root` arguments. During `tools/call`
processing for `llmx_index`, the server calls `roots/list` to get the project root.

This means:
- No hardcoded paths in tool arguments
- The client (Claude Code, VS Code, etc.) controls what the server can see
- Root changes trigger `notifications/roots/list_changed`, which llmx can use to
  invalidate caches and re-walk the file tree

### 1.3 Tiered Readiness Model

Incorporating the valid insight from the "Recursive Code Environment" document:

```
Server startup
│
├─ Tier 0 (instant, <100ms):
│  File manifest via ignore::WalkParallel
│  Tools available: llmx_search (BM25 over filenames/paths only)
│                   llmx_status (reports tier 0)
│                   llmx_explore (file tree browsing)
│
├─ Tier 1 (on-demand, <500ms per file):
│  Tree-sitter parse on first access
│  Symbols cached per-file in LRU
│  Tools gain: llmx_lookup (exact symbol match in parsed files)
│              llmx_refs (intra-file references in parsed files)
│
├─ Tier 2 (background, seconds to minutes):
│  Full structural index with SCIP IDs
│  fst-backed symbol index
│  Stack-graph cross-file resolution
│  Tools gain: llmx_lookup (full cross-file resolution)
│              llmx_graph_walk (multi-hop traversal)
│              llmx_search (structural ranking, symbol boosts)
│
├─ Tier 3 (background, minutes):
│  Vector embeddings (code-specific model)
│  Tools gain: llmx_search (semantic vector retrieval)
│
│  emit notifications/tools/list_changed (tool schemas updated
│  with richer outputSchema as tiers complete)
```

**Critical**: the server never blocks on Tier 2/3. Every tool returns the best result
available at the current tier, with a `readiness_tier` field in `structuredContent`
so the agent knows what quality level it's getting.

### 1.4 Filesystem Watching

The server sets up `inotify` (Linux) / `FSEvents` (macOS) / `ReadDirectoryChangesW`
(Windows) watches on all roots from `roots/list`. On file change:

1. Invalidate that file's cached tree-sitter parse (Tier 1 cache)
2. Mark affected SCIP symbols as stale in the fst index (Tier 2)
3. Queue background re-parse and re-embed for changed files
4. Emit `notifications/resources/updated` for the changed file URI
5. If symbol table changes, emit `notifications/tools/list_changed`
   (tool output schemas may reflect new symbols)

The `notify` crate (cross-platform) handles this. Cost: one fd per watched directory,
~100 bytes per watch. Scales to 100k+ directories.

---

## Part 2: Complete Tool Surface Redesign

### Design Principles Applied to All Tools

From the MCP spec:

1. **Every tool gets `annotations`**: `readOnlyHint`, `destructiveHint`,
   `idempotentHint`, `openWorldHint` — these control auto-approval in agent loops.
2. **Every tool gets `outputSchema`**: Structured content for programmatic consumption.
   Text `content` block is always present for backwards compat.
3. **Every tool gets `execution.taskSupport`**: "optional" for potentially slow tools,
   "forbidden" for instant ones.
4. **Tool results use `resource_link`** for source files instead of inlining content
   when the result set is large. This keeps responses compact and lets clients
   lazily fetch content.
5. **Tool names follow spec**: 1-128 chars, `[A-Za-z0-9_\-.]`, case-sensitive.

---

### Tool 1: `llmx_status`

**Purpose**: Report server readiness, index state, and capabilities. Agents should call
this first to understand what queries are possible.

```json
{
  "name": "llmx_status",
  "title": "Index Status",
  "description": "Report current index readiness tier, indexed file count, available capabilities, and background task progress. Call this to understand what query quality is currently available.",
  "inputSchema": {
    "type": "object",
    "additionalProperties": false
  },
  "outputSchema": {
    "type": "object",
    "properties": {
      "readiness_tier": {
        "type": "integer",
        "minimum": 0,
        "maximum": 3,
        "description": "Current readiness: 0=manifest, 1=on-demand-parse, 2=full-structural, 3=embeddings"
      },
      "files_indexed": { "type": "integer" },
      "files_total": { "type": "integer" },
      "symbols_indexed": { "type": "integer" },
      "embeddings_ready": { "type": "boolean" },
      "languages": {
        "type": "array",
        "description": "Languages detected with resolution tier per language"
      },
      "stale_files": {
        "type": "integer",
        "description": "Files modified since last index update"
      },
      "background_tasks": {
        "type": "array",
        "description": "Active background indexing tasks"
      }
    },
    "required": ["readiness_tier", "files_indexed", "files_total", "symbols_indexed", "embeddings_ready"]
  },
  "annotations": {
    "readOnlyHint": true,
    "destructiveHint": false,
    "idempotentHint": true,
    "openWorldHint": false
  },
  "execution": {
    "taskSupport": "forbidden"
  }
}
```

**Agent utility**: An agent starts every session with `llmx_status`. If
`readiness_tier < 2`, it knows to prefer `llmx_lookup` (on-demand parse) over
`llmx_graph_walk` (needs full index). This is the "agent IS the retrieval strategy"
insight, made concrete through structured metadata.

---

### Tool 2: `llmx_search`

**Purpose**: Multi-strategy search across the codebase. The primary discovery tool.

```json
{
  "name": "llmx_search",
  "title": "Code Search",
  "description": "Search code using BM25 keyword matching, semantic vector similarity, or structural symbol matching. Returns ranked results with inline content. Quality depends on current readiness tier — at Tier 0, only filename/path matching; at Tier 2+, full structural ranking with symbol boosts; at Tier 3, semantic vector retrieval.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "query": {
        "type": "string",
        "description": "Search query — natural language, symbol name, or code fragment"
      },
      "intent": {
        "type": "string",
        "enum": ["auto", "symbol", "semantic", "keyword", "filename"],
        "default": "auto",
        "description": "Search strategy hint. 'auto' lets the server choose based on query shape."
      },
      "path_prefix": {
        "type": "string",
        "description": "Filter to files under this root-relative path prefix"
      },
      "language": {
        "type": "string",
        "description": "Filter to files of this language (e.g. 'rust', 'python')"
      },
      "max_results": {
        "type": "integer",
        "default": 10,
        "minimum": 1,
        "maximum": 50
      },
      "include_content": {
        "type": "boolean",
        "default": true,
        "description": "Include inline source content in results. Set false for compact results with resource_links."
      }
    },
    "required": ["query"]
  },
  "outputSchema": {
    "type": "object",
    "properties": {
      "results": {
        "type": "array",
        "description": "Ranked search results"
      },
      "strategy_used": {
        "type": "string",
        "enum": ["bm25", "symbol_exact", "symbol_fuzzy", "vector", "hybrid", "filename"],
        "description": "Which retrieval strategy was actually used"
      },
      "readiness_tier": {
        "type": "integer",
        "description": "Server readiness at time of query"
      },
      "total_matches": { "type": "integer" },
      "truncated": { "type": "boolean" }
    },
    "required": ["results", "strategy_used", "readiness_tier", "total_matches", "truncated"]
  },
  "annotations": {
    "readOnlyHint": true,
    "destructiveHint": false,
    "idempotentHint": true,
    "openWorldHint": false
  },
  "execution": {
    "taskSupport": "optional"
  }
}
```

**Key design decisions**:

- `intent` replaces the old implicit routing. The agent can explicitly ask for
  `"symbol"` intent when it knows it's looking for a definition, or `"semantic"` when
  it wants conceptual similarity. `"auto"` is the default and uses heuristics (query
  looks like an identifier → symbol; query is natural language → semantic).
- `strategy_used` in the output tells the agent what actually happened. If the agent
  asked for `"semantic"` but the server is at Tier 1 (no embeddings), it falls back
  to BM25 and reports `"bm25"`. The agent can then decide whether to wait for Tier 3
  or proceed with what it has.
- `include_content: false` makes results return `resource_link` items per the MCP spec
  instead of inlining source text. This is crucial for large result sets — the agent
  gets compact metadata and can selectively fetch content for interesting results.
- `taskSupport: "optional"` because semantic search over large corpora can be slow.

**Result content format** (when `include_content: true`):

```json
{
  "content": [
    {
      "type": "text",
      "text": "Found 3 results for 'codex_exec':\n1. src/exec.rs:42 — fn codex_exec(...)\n..."
    },
    {
      "type": "resource",
      "resource": {
        "uri": "file:///project/src/exec.rs",
        "mimeType": "text/x-rust",
        "text": "pub fn codex_exec(args: &ExecArgs) -> Result<()> {\n    ...\n}"
      }
    }
  ],
  "structuredContent": {
    "results": [
      {
        "symbol_id": "rust-analyzer cargo llmx-core 0.1.0 src/exec.rs/codex_exec().",
        "symbol_tail": "codex_exec",
        "file_path": "src/exec.rs",
        "line": 42,
        "kind": "function",
        "visibility": "pub",
        "score": 0.95,
        "resolution_tier": "StackGraph",
        "content": "pub fn codex_exec(args: &ExecArgs) -> Result<()> { ... }"
      }
    ],
    "strategy_used": "symbol_exact",
    "readiness_tier": 2,
    "total_matches": 3,
    "truncated": false
  }
}
```

**Result content format** (when `include_content: false`):

```json
{
  "content": [
    {
      "type": "text",
      "text": "Found 3 results for 'codex_exec'. Use resource links to fetch content."
    },
    {
      "type": "resource_link",
      "uri": "file:///project/src/exec.rs",
      "name": "src/exec.rs:42 — codex_exec",
      "description": "fn codex_exec(args: &ExecArgs) -> Result<()>",
      "mimeType": "text/x-rust"
    }
  ],
  "structuredContent": { "..." }
}
```

---

### Tool 3: `llmx_lookup`

**Purpose**: Exact symbol resolution. The precision tool.

```json
{
  "name": "llmx_lookup",
  "title": "Symbol Lookup",
  "description": "Resolve a symbol name to its definition(s). Supports exact SCIP ID match, tail-name match, prefix match, and fuzzy containment. At Tier 1+, triggers on-demand tree-sitter parse for uncached files.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "symbol": {
        "type": "string",
        "description": "Symbol name, tail name, or SCIP-format symbol ID"
      },
      "mode": {
        "type": "string",
        "enum": ["auto", "exact", "tail", "prefix", "contains", "qualified"],
        "default": "auto",
        "description": "Match mode. 'auto' tries exact → tail → contains."
      },
      "language": {
        "type": "string",
        "description": "Filter to this language"
      },
      "max_results": {
        "type": "integer",
        "default": 5,
        "minimum": 1,
        "maximum": 20
      }
    },
    "required": ["symbol"]
  },
  "outputSchema": {
    "type": "object",
    "properties": {
      "definitions": {
        "type": "array",
        "description": "Resolved symbol definitions with content"
      },
      "mode_used": {
        "type": "string",
        "enum": ["exact", "tail", "prefix", "contains", "qualified"]
      },
      "readiness_tier": { "type": "integer" }
    },
    "required": ["definitions", "mode_used", "readiness_tier"]
  },
  "annotations": {
    "readOnlyHint": true,
    "destructiveHint": false,
    "idempotentHint": true,
    "openWorldHint": false
  },
  "execution": {
    "taskSupport": "forbidden"
  }
}
```

**Why `taskSupport: "forbidden"`**: Symbol lookup should be fast — fst index lookup at
Tier 2, or on-demand tree-sitter parse at Tier 1. If it's slow, something is wrong.

**On-demand parse behavior** (Tier 1): When the agent calls `llmx_lookup("codex_exec")`
and the full index isn't ready, the server:
1. Searches the file manifest for likely candidates (files named `exec.rs`, etc.)
2. Tree-sitter parses those files on-demand
3. Caches the parse results
4. Returns the match

This is the valid part of the "Recursive Code Environment" insight — the tool is
useful before full indexing, but not because we threw out the index; because we
made the tool gracefully degrade.

---

### Tool 4: `llmx_graph_walk`

**Purpose**: Traverse the structural code graph for multi-hop reasoning.

```json
{
  "name": "llmx_graph_walk",
  "title": "Code Graph Traversal",
  "description": "Traverse the structural code graph from a symbol to find callers, callees, imports, or dependents. Returns matched symbols with optional inline source content. Supports multi-hop traversal for agentic code reasoning. Requires Tier 2 readiness for cross-file edges; at Tier 1, returns intra-file edges only.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "symbol": {
        "type": "string",
        "description": "Symbol name, tail name, or SCIP-format symbol ID"
      },
      "direction": {
        "type": "string",
        "enum": ["callers", "callees", "imports", "dependents", "type_refs"],
        "description": "Edge direction to traverse"
      },
      "depth": {
        "type": "integer",
        "minimum": 1,
        "maximum": 3,
        "default": 1,
        "description": "Traversal depth (hops)"
      },
      "include_content": {
        "type": "boolean",
        "default": true,
        "description": "Include inline source content per hop"
      },
      "filter": {
        "type": "object",
        "properties": {
          "file_pattern": { "type": "string", "description": "Glob pattern for file filtering" },
          "language": { "type": "string" },
          "visibility": { "type": "string", "enum": ["pub", "crate", "private", "any"], "default": "any" }
        },
        "description": "Filter traversal results"
      },
      "max_results": {
        "type": "integer",
        "default": 20,
        "minimum": 1,
        "maximum": 100
      }
    },
    "required": ["symbol", "direction"]
  },
  "outputSchema": {
    "type": "object",
    "properties": {
      "matches": {
        "type": "array",
        "description": "Symbols found at each hop with edge metadata"
      },
      "total_count": { "type": "integer" },
      "truncated": { "type": "boolean" },
      "traversal_depth_reached": { "type": "integer" },
      "readiness_tier": { "type": "integer" },
      "edge_confidence": {
        "type": "string",
        "enum": ["precise", "heuristic", "intra_file_only"],
        "description": "Confidence level of the edges returned"
      }
    },
    "required": ["matches", "total_count", "truncated", "traversal_depth_reached", "readiness_tier", "edge_confidence"]
  },
  "annotations": {
    "readOnlyHint": true,
    "destructiveHint": false,
    "idempotentHint": true,
    "openWorldHint": false
  },
  "execution": {
    "taskSupport": "optional"
  }
}
```

**The filter parameter** is the addition I flagged in the previous review — it prevents
the "return 100 results and let the LLM figure it out" anti-pattern.

**`edge_confidence`** in the output tells the agent whether the graph edges are precise
(stack-graphs resolved) or heuristic (name-matching from query packs) or limited to
intra-file. This lets the agent decide whether to trust the results or do additional
verification.

---

### Tool 5: `llmx_explore`

**Purpose**: File tree browsing and structural overview. Discovery tool for agents that
don't know the codebase layout.

```json
{
  "name": "llmx_explore",
  "title": "Codebase Explorer",
  "description": "Browse the file tree, list symbols in a file, or get a structural overview of a directory. Available at all readiness tiers — uses the file manifest at Tier 0, adds symbol listings at Tier 1+.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "path": {
        "type": "string",
        "default": "",
        "description": "Root-relative path to explore. Empty string for project root."
      },
      "mode": {
        "type": "string",
        "enum": ["tree", "symbols", "overview"],
        "default": "tree",
        "description": "'tree': list files/dirs. 'symbols': list symbols in a file. 'overview': structural summary of a directory."
      },
      "depth": {
        "type": "integer",
        "minimum": 1,
        "maximum": 5,
        "default": 2,
        "description": "Directory listing depth for 'tree' mode"
      },
      "include_hidden": {
        "type": "boolean",
        "default": false
      }
    },
    "required": []
  },
  "outputSchema": {
    "type": "object",
    "properties": {
      "entries": { "type": "array", "description": "File/directory entries or symbol entries" },
      "path": { "type": "string" },
      "mode": { "type": "string" },
      "readiness_tier": { "type": "integer" }
    },
    "required": ["entries", "path", "mode", "readiness_tier"]
  },
  "annotations": {
    "readOnlyHint": true,
    "destructiveHint": false,
    "idempotentHint": true,
    "openWorldHint": false
  },
  "execution": {
    "taskSupport": "forbidden"
  }
}
```

**Agent utility**: This is the "Tier 0 is instantly useful" tool. The agent can
`llmx_explore(path="", mode="tree")` to see the project layout before any indexing
completes, then `llmx_explore(path="src/exec.rs", mode="symbols")` to get the symbol
list for a specific file via on-demand parse.

---

### Tool 6: `llmx_index`

**Purpose**: Trigger or manage indexing operations. The only non-read-only tool.

```json
{
  "name": "llmx_index",
  "title": "Index Management",
  "description": "Trigger full re-indexing, check index freshness, or invalidate cache for specific paths. Re-indexing runs as a background task — the server remains responsive during indexing.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "action": {
        "type": "string",
        "enum": ["reindex", "invalidate", "refresh"],
        "default": "refresh",
        "description": "'reindex': full rebuild. 'invalidate': mark specific paths stale. 'refresh': re-index only stale files."
      },
      "paths": {
        "type": "array",
        "items": { "type": "string" },
        "description": "Root-relative paths to invalidate (for 'invalidate' action)"
      }
    },
    "required": []
  },
  "outputSchema": {
    "type": "object",
    "properties": {
      "action": { "type": "string" },
      "files_affected": { "type": "integer" },
      "task_id": { "type": "string", "description": "Task ID for polling progress (if task-augmented)" },
      "estimated_duration_ms": { "type": "integer" }
    },
    "required": ["action", "files_affected"]
  },
  "annotations": {
    "readOnlyHint": false,
    "destructiveHint": false,
    "idempotentHint": true,
    "openWorldHint": false
  },
  "execution": {
    "taskSupport": "optional"
  }
}
```

**Task integration**: When called with a `progressToken` in the request `_meta`, the
server returns a task ID and emits `notifications/progress` with file-level granularity:

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/progress",
  "params": {
    "progressToken": "idx-001",
    "progress": 4200,
    "total": 25000,
    "message": "Parsing src/chunk/parsers/rust.rs (Tier 2)"
  }
}
```

The agent can monitor progress and decide whether to wait or proceed with Tier 1
results.

---

### Tool 7: `llmx_refs`

**Purpose**: Find all references to a symbol. Complement to `llmx_lookup` (which finds
definitions) and `llmx_graph_walk` (which follows typed edges).

```json
{
  "name": "llmx_refs",
  "title": "Find References",
  "description": "Find all references to a symbol across the indexed codebase. At Tier 1, returns references in parsed files only. At Tier 2+, returns cross-file references with edge types.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "symbol": {
        "type": "string",
        "description": "Symbol name or SCIP ID"
      },
      "include_definition": {
        "type": "boolean",
        "default": false,
        "description": "Include the definition site in results"
      },
      "path_prefix": {
        "type": "string",
        "description": "Filter to files under this path"
      },
      "max_results": {
        "type": "integer",
        "default": 20,
        "minimum": 1,
        "maximum": 100
      }
    },
    "required": ["symbol"]
  },
  "outputSchema": {
    "type": "object",
    "properties": {
      "references": { "type": "array" },
      "total_count": { "type": "integer" },
      "truncated": { "type": "boolean" },
      "readiness_tier": { "type": "integer" }
    },
    "required": ["references", "total_count", "truncated", "readiness_tier"]
  },
  "annotations": {
    "readOnlyHint": true,
    "destructiveHint": false,
    "idempotentHint": true,
    "openWorldHint": false
  },
  "execution": {
    "taskSupport": "optional"
  }
}
```

---

## Part 3: MCP Resources

llmx should expose MCP resources for two purposes:

### 3.1 Source File Resources

Every indexed file is a resource with URI `file:///<root-relative-path>`:

```json
{
  "uri": "file:///src/exec.rs",
  "name": "src/exec.rs",
  "description": "Rust source file (42 symbols, Tier 1: StackGraph)",
  "mimeType": "text/x-rust"
}
```

Clients can:
- `resources/read` to fetch file content
- `resources/subscribe` to get `notifications/resources/updated` on file change
  (via filesystem watcher)

### 3.2 Index State Resource

```json
{
  "uri": "llmx://index/status",
  "name": "Index Status",
  "description": "Current index readiness and statistics",
  "mimeType": "application/json"
}
```

This resource changes every time the index updates. Clients that subscribe get
live index readiness updates without polling `llmx_status`.

### 3.3 Symbol Table Resource

```json
{
  "uri": "llmx://symbols/{language}",
  "name": "Symbol Table (Rust)",
  "description": "All indexed symbols for Rust",
  "mimeType": "application/json"
}
```

This is a URI template. `resources/templates/list` exposes these.

---

## Part 4: Agent Workflow Patterns

### 4.1 First Contact Pattern

```
Agent → llmx_status()
       readiness_tier: 0, files_total: 25000
Agent → llmx_explore(path="", mode="tree", depth=2)
       entries: [src/, tests/, docs/, Cargo.toml, ...]
Agent → llmx_explore(path="src", mode="tree", depth=2)
       entries: [src/exec.rs, src/chunk/, src/graph.rs, ...]
Agent → llmx_lookup(symbol="codex_exec")
       # Tier 1: on-demand parse of src/exec.rs
       definitions: [{symbol_id: "...", file: "src/exec.rs", line: 42}]
```

The agent gets useful results in <1 second, before any background indexing.

### 4.2 Deep Investigation Pattern

```
Agent → llmx_status()
       readiness_tier: 2  # full structural index ready
Agent → llmx_lookup(symbol="codex_exec", mode="exact")
       definitions: [{symbol_id: "...", ...}]
Agent → llmx_graph_walk(symbol="codex_exec", direction="callers", depth=2)
       matches: [
         {symbol: "run_command", depth: 1, edge_type: "Calls", confidence: "precise"},
         {symbol: "main", depth: 2, edge_type: "Calls", confidence: "precise"}
       ]
Agent → llmx_graph_walk(symbol="run_command", direction="callees",
                         filter={visibility: "pub"})
       matches: [{symbol: "check_permissions", ...}, {symbol: "codex_exec", ...}]
Agent → synthesizes: "codex_exec is called by run_command, which first
         calls check_permissions. The call chain from main is:
         main → run_command → check_permissions → codex_exec"
```

### 4.3 Degraded Readiness Pattern

```
Agent → llmx_search(query="permission checking", intent="semantic")
       strategy_used: "bm25"  # Tier 3 not ready, fell back
       readiness_tier: 1
Agent → (sees strategy_used != "semantic", knows quality is lower)
Agent → llmx_search(query="check_permissions fn", intent="symbol")
       # Adapts strategy based on server feedback
       strategy_used: "symbol_fuzzy"
       results: [...]
```

The agent adapts its strategy based on `strategy_used` and `readiness_tier` in every
response. This is the "agent IS the retrieval strategy" insight — but implemented through
structured metadata in spec-compliant tool outputs, not through some mythical "Agentic
Retrieval Router" middleware layer.

---

## Part 5: What the "Recursive Code Environment" Gets Wrong

### 5.1 "Parse on Demand, Not Up Front" — False Dichotomy

You need both. On-demand parse gives you instant single-file answers. But:
- "Find all callers of X across the codebase" requires the full graph. You can't
  lazily parse 25,000 files on-demand for one query.
- Semantic search ("code that handles error recovery") requires embeddings over the
  full corpus. There's no lazy path to this.
- BM25 needs a term index. Even keyword search benefits from pre-computation.

The correct architecture is: **be useful immediately with on-demand, converge to
full-quality with background indexing, report the current quality level in every
tool response.**

### 5.2 "The Index as a Cache, Not a Product" — Renaming, Not Rethinking

Calling the index a "cache" doesn't change what it is — a persistent data structure
that accelerates queries. Whether you call it an index or a cache, it needs the same
data structures (fst for symbols, adjacency lists for the graph, vector store for
embeddings) and the same maintenance (invalidation on file change, migration on
schema change). The distinction is marketing.

What IS useful from this framing: the index should be treated as a cache in the sense
that it's **always optional for correctness**. Every tool should be able to produce a
result (possibly slower, possibly lower quality) without the index. This is what the
tiered readiness model achieves.

### 5.3 Phantom Citations

The document cites "MIT CSAIL's Recursive Language Models paper (Zhang, Kraska,
Khattab)", "CodeRLM", and "Codified Context paper." I cannot find any of these. The
LocAgent paper (real, early 2025) and CocoIndex (real) are cited alongside these
phantoms, lending them false credibility. Be cautious with unverifiable citations
used to support architectural arguments.

### 5.4 Code-Specific Embeddings — Correct but Orthogonal

Voyage-Code-3 and CodeSage are real and do outperform general-purpose models on code
retrieval. But this is an embedding model swap in the vector pipeline, not an
architectural change. It belongs as a line item in the dependency plan (swap
mdbr-leaf-ir → Voyage-Code-3 or CodeSage), not as a structural insight.

---

## Part 6: Summary of Changes to the Epic Plan

### Must Do (spec compliance)

| Change | Reason |
|--------|--------|
| Declare `tools`, `resources`, `tasks`, `logging` capabilities | MCP spec requires capability negotiation |
| Add `outputSchema` to all tools | Enables structured programmatic consumption by agents |
| Add `annotations` to all tools | Controls auto-approval in agent loops (especially `readOnlyHint`) |
| Add `execution.taskSupport` | Long-running operations (indexing, large graph walks) need task support |
| Use `roots/list` for project discovery | Spec-compliant alternative to hardcoded paths |
| Return `resource_link` in results | Spec-compliant lazy content loading |
| Emit `notifications/progress` during indexing | Spec-compliant progress reporting |
| Emit `notifications/tools/list_changed` on tier transitions | Spec-compliant tool discovery |

### Should Do (agent utility)

| Change | Reason |
|--------|--------|
| Tiered readiness model (Tier 0-3) | Instant usefulness, graceful degradation |
| `readiness_tier` in every tool output | Agent adapts strategy based on current quality |
| `strategy_used` in search output | Agent knows what actually happened |
| `edge_confidence` in graph walk output | Agent knows whether to trust graph edges |
| `filter` parameter on graph walk | Prevents "return 100 results, LLM figures it out" |
| Filesystem watching via `notify` crate | Eliminates stale index problem |
| `llmx_explore` tool for Tier 0 browsing | Useful before any indexing |
| `llmx_status` as the session-start tool | Agent learns capabilities before querying |

### Nice to Have

| Change | Reason |
|--------|--------|
| Swap embedding model to Voyage-Code-3 | 13-17% improvement on code retrieval benchmarks |
| `llmx_graph_neighborhood` tool (ego-graph) | More efficient than chained graph_walk for topology understanding |
| Expose symbol table as MCP resource with subscribe | Live symbol updates without polling |
| SCIP import from external indexers | Accept rust-analyzer/scip-typescript output |
