# Structural Indexing Epic Plan

Status: proposed implementation plan
Updated: 2026-03-13
Scope: `ingestor-core`, `ingestor-wasm`, MCP handlers, storage, ranking, and docs

## Goal

Turn `llmx` from a JS-biased text retriever into a real multi-language structural indexer that:

1. Indexes source files using language-aware parsers instead of generic text chunking.
2. Stores root-relative paths so path filters are stable and portable.
3. Makes symbol lookup reliable for Rust-first codebases and then top-10 major languages.
4. Ranks source code above docs, logs, and generated artifacts for code-shaped queries.
5. Exposes honest structural capability metadata in native and WASM builds.

## Primary User Outcomes

1. `llmx_lookup("codex_exec", mode="exact")` resolves the correct Rust definition.
2. `path_prefix: "core/src"` works regardless of machine-specific absolute roots.
3. `llmx_search("codex_exec", intent="symbol")` returns source definitions before docs or logs.
4. Rust-heavy repos are structurally searchable without falling back to `find`.
5. Native and WASM builds advertise clear structural language support instead of silently degrading.

## Delivery Sequence

1. Phase 1: schema v3, root-relative paths, shared `.gitignore`-aware walker, noisy artifact exclusion.
2. Phase 2: parser framework extraction, Rust adapter, canonical symbol IDs, lookup rewrite.
3. Phase 3: top-10 native language pack, ranking overhaul, graph-backed retrieval, WASM structural core pack.
4. Phase 4: extended 20+ native language pack and browser extended pack.

## Architecture Decisions

### 1. Separate `LanguageId` from `ChunkKind`

`ChunkKind` remains a coarse content bucket. `LanguageId` becomes the language-specific structural routing key.

Required new model fields:

- `language: Option<LanguageId>`
- `root_path: String`
- `relative_path: String`
- `is_generated: bool`
- `quality_score: Option<u16>`
- `symbol_id: Option<String>`
- `symbol_tail: Option<String>`
- `module_path: Option<String>`
- `visibility: Option<String>`

### 2. Move to parser adapters plus query packs

Do not keep growing `src/chunk.rs` with more `match node.kind()` branches.

Target module layout:

- `ingestor-core/src/chunk/mod.rs`
- `ingestor-core/src/chunk/language.rs`
- `ingestor-core/src/chunk/registry.rs`
- `ingestor-core/src/chunk/query_loader.rs`
- `ingestor-core/src/chunk/symbol_id.rs`
- `ingestor-core/src/chunk/parsers/*.rs`
- `ingestor-core/queries/<language>/*.scm`

### 3. Canonical symbol identity

Graph edges and symbol lookup should resolve on canonical `symbol_id`, not free-form names.

Examples:

- `rust://crate::core::exec::codex_exec`
- `python://pkg.module.Class.method`
- `go://module/pkg.Func`

### 4. One walking backend for all indexing paths

Persistent indexing and dynamic indexing must use the same `.gitignore`-aware walker and the same exclusion rules.

### 5. Deterministic ranking priors

RRF stays. Add deterministic priors:

- exact symbol boost
- exact identifier boost
- path-prefix boost
- source-file prior
- test/docs/generated/log penalties
- same-file neighbor bonus
- graph-neighbor bonus

## Phase 1

### Objective

Fix indexing correctness before parser expansion.

### Work Items

#### E1-01 Add schema v3 and `LanguageId`

Files:

- `ingestor-core/src/model.rs`

Changes:

- Bump `INDEX_VERSION` from `2` to `3`.
- Add `LanguageId`.
- Extend `FileMeta` and `Chunk` with path/language/generated fields.
- Add placeholder fields needed by later parser work.

Acceptance:

- The schema can represent root-relative files and language-specific structural metadata.

#### E1-02 Add root-relative path normalization

Files:

- `ingestor-core/src/pathnorm.rs`
- `ingestor-core/src/lib.rs`

Changes:

- Add helpers to compute a canonical root and relative path.
- Store `relative_path` in chunk/file records.
- Stop writing absolute paths into the searchable path field.

Acceptance:

- `path_prefix` operates on root-relative paths.

#### E1-03 Replace persistent walker with shared `.gitignore`-aware walker

Files:

- `ingestor-core/src/walk.rs`
- `ingestor-core/src/handlers/mod.rs`
- `ingestor-core/src/handlers/safety.rs`
- `ingestor-core/src/mcp/tools.rs`

Changes:

- Introduce a shared walker API.
- Remove the current persistent recursive directory walk.
- Route both persistent and dynamic indexing through the same backend.

Acceptance:

- Persistent indexing respects `.gitignore`, `.ignore`, and common exclusion rules.

#### E1-04 Add deterministic noisy artifact exclusion

Files:

- `ingestor-core/src/walk.rs`
- `ingestor-core/src/util.rs`
- `ingestor-core/src/index.rs`

Changes:

- Exclude or tag as generated:
  - `export/`
  - `llmx-export/`
  - `*.log`
  - `*.zip`
  - `target/`
  - `dist/`
  - `build/`
  - `.next/`
  - `.turbo/`
  - `coverage/`
  - `node_modules/`
- Add path-based and name-based generated heuristics.

Acceptance:

- Generated outputs and logs no longer dominate BM25 for source queries.

#### E1-05 Enforce schema compatibility on load

Files:

- `ingestor-core/src/handlers/storage.rs`
- `ingestor-core/src/mcp/storage.rs`

Changes:

- Validate schema version and structural capabilities when loading.
- Rebuild or reject incompatible v2 indexes instead of silently reusing them.

Acceptance:

- Old path-format and missing-structure indexes do not masquerade as current indexes.

#### E1-06 Update public docs

Files:

- `docs/INGESTION_SPEC.md`
- `README.md`

Changes:

- Document root-relative paths.
- Document current structural support matrix honestly.

#### E1-07 Add tests

Files:

- `ingestor-core/tests/path_normalization_tests.rs`
- `ingestor-core/tests/walk_filter_tests.rs`
- `ingestor-core/tests/schema_migration_tests.rs`
- `ingestor-core/tests/noise_ranking_tests.rs`

Acceptance:

- Current path-filter and noisy-results failures are covered by tests.

## Phase 2

### Objective

Replace the monolithic chunker with a parser framework and ship Rust structural indexing first.

### Work Items

#### E2-01 Split `chunk.rs` into a real module tree

Files:

- `ingestor-core/src/chunk.rs`
- `ingestor-core/src/chunk/mod.rs`

Changes:

- Move real logic out of `chunk.rs`.
- Keep `chunk.rs` as a compatibility shim temporarily if needed.

#### E2-02 Define parser contracts

Files:

- `ingestor-core/src/chunk/language.rs`
- `ingestor-core/src/model.rs`

Changes:

- Add `LanguageAdapter`, `ParseOptions`, `ParseResult`.
- Standardize returned structural metadata.

#### E2-03 Add parser registry and dispatch

Files:

- `ingestor-core/src/chunk/registry.rs`
- `ingestor-core/src/util.rs`
- `ingestor-core/src/lib.rs`

Changes:

- Replace `detect_kind()`-only routing with `detect_language()` plus adapter dispatch.
- Stop treating Rust/Python/Go as `Unknown`.

#### E2-04 Add tree-sitter query loader

Files:

- `ingestor-core/src/chunk/query_loader.rs`
- `ingestor-core/queries/`

Changes:

- Load `defs`, `imports`, `calls`, `types`, `docs`, `tests`, and `namespace` queries from `.scm` files.

#### E2-05 Add canonical symbol ID generation

Files:

- `ingestor-core/src/chunk/symbol_id.rs`
- `ingestor-core/src/graph.rs`
- `ingestor-core/src/model.rs`

Changes:

- Generate stable `symbol_id` values by language.
- Prepare graph and symbol table to key on `symbol_id`.

#### E2-06 Add parser framework tests

Files:

- `ingestor-core/tests/parser_framework_tests.rs`
- `ingestor-core/tests/fixtures/projects/`

Acceptance:

- Registry dispatch, query loading, and fallback behavior are covered before language-specific rollout.

### Rust-First Structural Work

#### E3-01 Add Rust grammar dependency and adapter skeleton

Files:

- `ingestor-core/Cargo.toml`
- `ingestor-core/src/chunk/parsers/rust.rs`

#### E3-02 Implement Rust definition extraction

Files:

- `ingestor-core/src/chunk/parsers/rust.rs`
- `ingestor-core/queries/rust/defs.scm`

Support:

- `fn`
- `struct`
- `enum`
- `trait`
- `type`
- `const`
- `static`
- `mod`
- `impl`
- methods

#### E3-03 Implement Rust imports, calls, and type refs

Files:

- `ingestor-core/src/chunk/parsers/rust.rs`
- `ingestor-core/queries/rust/imports.scm`
- `ingestor-core/queries/rust/calls.scm`
- `ingestor-core/queries/rust/types.scm`

#### E3-04 Implement Rust docs, visibility, and tests

Files:

- `ingestor-core/src/chunk/parsers/rust.rs`
- `ingestor-core/queries/rust/docs.scm`
- `ingestor-core/queries/rust/tests.scm`

#### E3-05 Canonicalize Rust qualified names and symbol IDs

Files:

- `ingestor-core/src/chunk/parsers/rust.rs`
- `ingestor-core/src/chunk/symbol_id.rs`
- `ingestor-core/src/graph.rs`

#### E3-06 Add Rust parser tests

Files:

- `ingestor-core/tests/rust_parser_tests.rs`
- `ingestor-core/tests/fixtures/filetypes/rust/`

Acceptance:

1. Rust files no longer go through `ChunkKind::Unknown -> chunk_text()`.
2. `codex_exec`-style definitions resolve through the structural index.
3. Rust graph edges are populated for imports, calls, and type refs.

### JS/TS Migration

#### E4-01 Move existing JS extraction into adapter form

Files:

- `ingestor-core/src/chunk/parsers/javascript.rs`

#### E4-02 Separate TS/TSX adapter with query packs

Files:

- `ingestor-core/src/chunk/parsers/typescript.rs`
- `ingestor-core/queries/typescript/`

#### E4-03 Preserve JS/TS regression coverage

Files:

- `ingestor-core/tests/`
- `ingestor-wasm/src/backend_tests.rs`

## Phase 3

### Objective

Ship a serious native top-10 pack, rewrite lookup, improve ranking, and restore structural parity in WASM.

### Top-10 Native Pack

#### E5-01 Python adapter

Files:

- `ingestor-core/src/chunk/parsers/python.rs`
- `ingestor-core/queries/python/`

#### E5-02 Go adapter

Files:

- `ingestor-core/src/chunk/parsers/go.rs`
- `ingestor-core/queries/go/`

#### E5-03 Java adapter

Files:

- `ingestor-core/src/chunk/parsers/java.rs`
- `ingestor-core/queries/java/`

#### E5-04 C adapter

Files:

- `ingestor-core/src/chunk/parsers/c.rs`
- `ingestor-core/queries/c/`

#### E5-05 C++ adapter

Files:

- `ingestor-core/src/chunk/parsers/cpp.rs`
- `ingestor-core/queries/cpp/`

#### E5-06 C# adapter

Files:

- `ingestor-core/src/chunk/parsers/csharp.rs`
- `ingestor-core/queries/csharp/`

#### E5-07 Cross-language tests

Files:

- `ingestor-core/tests/python_parser_tests.rs`
- `ingestor-core/tests/go_parser_tests.rs`
- `ingestor-core/tests/java_parser_tests.rs`
- `ingestor-core/tests/c_family_parser_tests.rs`

### Lookup and Identifier Index

#### E6-01 Add exact identifier index

Files:

- `ingestor-core/src/model.rs`
- `ingestor-core/src/index.rs`
- `ingestor-core/src/lib.rs`

#### E6-02 Add explicit lookup modes

Files:

- `ingestor-core/src/handlers/mod.rs`
- `ingestor-core/src/handlers/types.rs`
- `ingestor-core/src/mcp/tools.rs`

Modes:

- `exact`
- `prefix`
- `contains`
- `tail`
- `qualified`
- `auto`

#### E6-03 Rewrite symbol search on canonical fields

Files:

- `ingestor-core/src/symbol_search.rs`
- `ingestor-core/src/graph.rs`

#### E6-04 Add lookup tests

Files:

- `ingestor-core/tests/lookup_modes_tests.rs`
- `ingestor-core/tests/identifier_index_tests.rs`

Acceptance:

1. `contains` mode covers the user intent behind `*exec*`.
2. Exact identifier lookup does not degrade `codex_exec` into generic BM25 noise.

### Graph Canonicalization

#### E7-01 Rebuild symbol table around `symbol_id`

Files:

- `ingestor-core/src/graph.rs`
- `ingestor-core/src/model.rs`

#### E7-02 Rewrite edge index on canonical IDs

Files:

- `ingestor-core/src/graph.rs`

#### E7-03 Add graph-walk tests

Files:

- `ingestor-core/tests/graph_expansion_tests.rs`

### Ranking Overhaul

#### E8-01 Add deterministic source priors

Files:

- `ingestor-core/src/index.rs`
- `ingestor-core/src/lib.rs`

#### E8-02 Add exact symbol and identifier boosts

Files:

- `ingestor-core/src/index.rs`
- `ingestor-core/src/query.rs`

#### E8-03 Add same-file and graph-neighbor expansion

Files:

- `ingestor-core/src/index.rs`
- `ingestor-core/src/graph.rs`

#### E8-04 Add ranking regression tests

Files:

- `ingestor-core/tests/ranking_priors_tests.rs`
- `ingestor-core/tests/noise_ranking_tests.rs`

Acceptance:

- Source files consistently outrank docs, logs, and generated artifacts for code-focused queries.

### WASM Structural Core Pack

#### E9-01 Add browser structural core pack

Files:

- `ingestor-wasm/Cargo.toml`
- `ingestor-wasm/src/lib.rs`

Core pack:

1. Rust
2. JavaScript
3. TypeScript
4. TSX
5. Python
6. Go

#### E9-02 Expose capability metadata and notices

Files:

- `ingestor-wasm/src/lib.rs`
- `README.md`
- `docs/INGESTION_SPEC.md`

#### E9-03 Add structural parity tests

Files:

- `ingestor-wasm/tests/structural_parity_tests.rs`

Acceptance:

- WASM exposes honest language support and produces comparable results for the core pack.

## Phase 4

### Objective

Expand to 20+ native languages and optional extended browser support.

### Extended Native Language Pack

#### E10-01 JVM and mobile pack

Languages:

- Kotlin
- Scala
- Swift
- Dart

#### E10-02 Scripting and backend pack

Languages:

- Ruby
- PHP
- Bash
- Lua
- Perl

#### E10-03 Infra and config pack

Languages:

- SQL
- HCL
- YAML
- TOML
- Nix

#### E10-04 Functional and specialized pack

Languages:

- Elixir
- OCaml
- Julia
- R
- Solidity
- Zig

#### E10-05 Language pack audit and maintenance policy

Files:

- `README.md`
- `docs/`

Acceptance:

- Native build supports 20+ major languages with documented quality and maintenance status.

## Dependency Plan

### Core Runtime

Add:

- `compact_str`
- `rustc-hash`
- `smallvec`
- `rayon`
- `globset`
- `fst`
- `memchr`

### Tree-sitter Language Pack

Phase 2 and 3 should upgrade the tree-sitter stack consistently, then add:

- `tree-sitter-rust`
- `tree-sitter-python`
- `tree-sitter-go`
- `tree-sitter-java`
- `tree-sitter-c`
- `tree-sitter-cpp`
- `tree-sitter-c-sharp`

Phase 4 adds maintained grammar crates for the extended pack.

### Optional Native Enrichers

Only if tree-sitter extraction proves insufficient:

- `ra_ap_syntax`
- `rustpython-parser`

These should stay feature-gated and non-default.

## Dependency Graph

1. `E1-01 -> E1-02 -> E1-03 -> E1-04 -> E1-05 -> E1-07`
2. `E1-01 -> E2-01 -> E2-02 -> E2-03 -> E2-04`
3. `E2-02 -> E2-05`
4. `E2-03 + E2-04 + E2-05 -> E3-01 -> E3-02 -> E3-03 -> E3-04 -> E3-05 -> E3-06`
5. `E2-03 + E2-04 -> E4-01 -> E4-02 -> E4-03`
6. `E2-03 + E2-04 -> E5-01..E5-06 -> E5-07`
7. `E3-05 + E5-07 -> E6-01 -> E6-02 -> E6-03 -> E6-04`
8. `E3-05 + E6-01 -> E7-01 -> E7-02 -> E7-03`
9. `E1-04 + E6-03 -> E8-01`
10. `E6-01 + E6-03 -> E8-02`
11. `E7-02 + E8-02 -> E8-03 -> E8-04`
12. `E3-06 + E4-03 + E5-01 + E5-02 -> E9-01 -> E9-02 -> E9-03`
13. `E5-07 -> E10-01..E10-04 -> E10-05`

## Critical Path

1. Phase 1 foundation
2. Parser framework
3. Rust structural indexing
4. Lookup rewrite
5. Ranking overhaul
6. WASM structural core pack

## File Execution Order

1. `ingestor-core/src/model.rs`
2. `ingestor-core/src/pathnorm.rs`
3. `ingestor-core/src/walk.rs`
4. `ingestor-core/src/handlers/safety.rs`
5. `ingestor-core/src/handlers/mod.rs`
6. `ingestor-core/src/mcp/tools.rs`
7. `ingestor-core/src/lib.rs`
8. `ingestor-core/src/handlers/storage.rs`
9. `ingestor-core/src/mcp/storage.rs`
10. `ingestor-core/src/index.rs`
11. `ingestor-core/src/util.rs`
12. `ingestor-core/src/chunk/mod.rs`
13. `ingestor-core/src/chunk/language.rs`
14. `ingestor-core/src/chunk/registry.rs`
15. `ingestor-core/src/chunk/query_loader.rs`
16. `ingestor-core/src/chunk/symbol_id.rs`
17. `ingestor-core/src/chunk.rs`
18. `ingestor-core/src/chunk/parsers/rust.rs`
19. `ingestor-core/queries/rust/defs.scm`
20. `ingestor-core/queries/rust/imports.scm`
21. `ingestor-core/queries/rust/calls.scm`
22. `ingestor-core/queries/rust/types.scm`
23. `ingestor-core/queries/rust/docs.scm`
24. `ingestor-core/queries/rust/tests.scm`
25. `ingestor-core/src/graph.rs`
26. `ingestor-core/src/symbol_search.rs`
27. `ingestor-core/src/handlers/types.rs`
28. `ingestor-core/src/handlers/mod.rs` for lookup rewrite
29. `ingestor-core/src/chunk/parsers/javascript.rs`
30. `ingestor-core/src/chunk/parsers/typescript.rs`
31. `ingestor-core/src/chunk/parsers/python.rs`
32. `ingestor-core/src/chunk/parsers/go.rs`
33. `ingestor-core/src/chunk/parsers/java.rs`
34. `ingestor-core/src/chunk/parsers/c.rs`
35. `ingestor-core/src/chunk/parsers/cpp.rs`
36. `ingestor-core/src/chunk/parsers/csharp.rs`
37. `ingestor-wasm/Cargo.toml`
38. `ingestor-wasm/src/lib.rs`

## First 12 Starter Issues

1. `E1-01` Add schema v3 and `LanguageId`
2. `E1-02` Add root-relative path normalization
3. `E1-03` Replace persistent walker with shared walker
4. `E1-04` Add deterministic noisy artifact exclusion
5. `E1-05` Enforce schema compatibility on load
6. `E1-07` Add path/walker/migration tests
7. `E2-01` Split `chunk.rs` into a module tree
8. `E2-02` Define parser contracts
9. `E2-03` Add parser registry and dispatch
10. `E2-04` Add tree-sitter query loader
11. `E2-05` Add canonical symbol ID generation
12. `E3-01` Add Rust grammar dependency and adapter skeleton

## Exit Criteria

This plan is complete when:

1. Native `llmx` structurally indexes at least 20 major languages.
2. WASM exposes a documented structural core pack.
3. Symbol lookup is exact and dependable for Rust-heavy codebases.
4. Path filters are stable and root-relative.
5. Search quality is source-first and deterministic.
