const state = {
  backend: null,
  workerReady: false,
  indexLoaded: false,
  busy: false,
  indexId: null,
  files: [],
  searchSeq: 0,
};

const elements = {
  status: document.getElementById("ingest-status"),
  selectFolder: document.getElementById("select-folder"),
  selectFiles: document.getElementById("select-files"),
  folderInput: document.getElementById("folder-input"),
  filesInput: document.getElementById("files-input"),
  dropZone: document.getElementById("drop-zone"),
  query: document.getElementById("query"),
  pathFilter: document.getElementById("path-filter"),
  fileFilter: document.getElementById("file-filter"),
  outlineFilter: document.getElementById("outline-filter"),
  symbolFilter: document.getElementById("symbol-filter"),
  kindFilter: document.getElementById("kind-filter"),
  runSearch: document.getElementById("run-search"),
  results: document.getElementById("results"),
  chunkView: document.getElementById("chunk-view"),
  chunkTitle: document.getElementById("chunk-title"),
  chunkContent: document.getElementById("chunk-content"),
  closeChunk: document.getElementById("close-chunk"),
  exportLlmPointer: document.getElementById("export-llm-pointer"),
  exportCatalogLlm: document.getElementById("export-catalog-llm"),
  exportManifestLlmTsv: document.getElementById("export-manifest-llm-tsv"),
  exportLlmOutline: document.getElementById("export-llm-outline"),
  exportZip: document.getElementById("export-zip"),
  exportZipCompact: document.getElementById("export-zip-compact"),
  saveIndex: document.getElementById("save-index"),
  indexId: document.getElementById("index-id"),
  chunkCount: document.getElementById("chunk-count"),
  warningCount: document.getElementById("warning-count"),
  warningList: document.getElementById("warning-list"),
  savedIndexes: document.getElementById("saved-indexes"),
  loadSavedIndex: document.getElementById("load-saved-index"),
  deleteSavedIndex: document.getElementById("delete-saved-index"),
};

const webGpuRequested = (() => {
  try {
    return new URL(window.location.href).searchParams.get("webgpu") === "1";
  } catch {
    return false;
  }
})();
const forceWebGpu = (() => {
  try {
    return new URL(window.location.href).searchParams.get("force_webgpu") === "1";
  } catch {
    return false;
  }
})();
const embeddingsRequested = (() => {
  try {
    const params = new URL(window.location.href).searchParams;
    return params.get("embeddings") === "1";
  } catch {
    return false;
  }
})();
const isFirefox = (() => {
  const ua = window.navigator?.userAgent || "";
  return ua.includes("Firefox/") && !ua.includes("Seamonkey/");
})();
const webGpuAvailable = Boolean(window.navigator && window.navigator.gpu);
globalThis.LLMX_ENABLE_WEBGPU = webGpuRequested && webGpuAvailable;
globalThis.LLMX_ENABLE_EMBEDDINGS = embeddingsRequested;
if (webGpuRequested && !webGpuAvailable) {
  console.warn("WebGPU requested via ?webgpu=1 but navigator.gpu is unavailable; disabling.");
}
if (webGpuRequested && isFirefox && !forceWebGpu) {
  globalThis.LLMX_ENABLE_WEBGPU = false;
  console.warn(
    "WebGPU requested on Firefox, but is disabled by default due to stability issues. Use Chromium, or add ?force_webgpu=1 to override."
  );
}

const ALLOWED_EXTENSIONS = [
  ".md",
  ".markdown",
  ".json",
  ".txt",
  ".js",
  ".ts",
  ".tsx",
  ".html",
  ".htm",
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
  ".gif",
  ".bmp",
];
const SKIP_DIRS = [".git", "node_modules", "target", "dist", "build", ".cache"];
const DEFAULT_LIMITS = {
  maxFileBytes: 5 * 1024 * 1024,     // 5MB per file (reduced from 10MB)
  maxTotalBytes: 25 * 1024 * 1024,   // 25MB total (reduced from 50MB)
  maxFileCount: 500,                  // Maximum 500 files
  warnFileBytes: 1 * 1024 * 1024,    // Warn at 1MB per file
  warnTotalBytes: 10 * 1024 * 1024,  // Warn at 10MB total
};

function setStatus(message) {
  elements.status.textContent = message;
}

function hasFolderPickerSupport() {
  const supportsDirectoryPicker = typeof window.showDirectoryPicker === "function";
  const supportsWebkitDirectory = elements.folderInput && "webkitdirectory" in elements.folderInput;
  return supportsDirectoryPicker || supportsWebkitDirectory;
}

function configureFolderPickerUi() {
  if (hasFolderPickerSupport()) {
    return;
  }
  elements.selectFolder.disabled = true;
  elements.selectFolder.title = "Folder selection is not supported in this browser. Use Select files or drag-and-drop.";
}

let workerCallId = 0;
const pendingCalls = new Map();

function formatErrorForUi(error) {
  const message = error instanceof Error ? error.message : String(error || "Unknown error");
  const cleaned = message.replace(/\s+/g, " ").trim();
  return cleaned.length > 240 ? `${cleaned.slice(0, 237)}...` : cleaned;
}

function rejectAllPendingWorkerCalls(message) {
  for (const pending of pendingCalls.values()) {
    pending.reject(new Error(message));
  }
  pendingCalls.clear();
}

function callWorker(op, payload, transfer) {
  if (!state.backend) {
    return Promise.reject(new Error("Backend not initialized"));
  }
  return state.backend.call(op, payload, transfer);
}

function createWorkerBackend() {
  const worker = new Worker(new URL("./worker.js", import.meta.url), { type: "module" });
  worker.onmessage = (event) => {
    const msg = event.data || {};
    const pending = pendingCalls.get(msg.id);
    if (!pending) {
      return;
    }
    pendingCalls.delete(msg.id);
    if (msg.ok) {
      pending.resolve(msg.data);
    } else {
      pending.reject(new Error(msg.error || "Worker error"));
    }
  };
  worker.onerror = (event) => {
    const message = event?.message ? `Worker error: ${event.message}` : "Worker error";
    if (event?.error?.stack) {
      console.error(`${message}\n${event.error.stack}`);
    } else {
      console.error(message, event?.error);
    }
    rejectAllPendingWorkerCalls(message);
    setStatus(message);
  };
  worker.onmessageerror = () => {
    const message = "Worker message error (structured clone failed).";
    rejectAllPendingWorkerCalls(message);
    setStatus(message);
  };

  return {
    kind: "worker",
    call(op, payload, transfer) {
      const id = ++workerCallId;
      return new Promise((resolve, reject) => {
        pendingCalls.set(id, { resolve, reject });
        worker.postMessage({ id, op, payload }, transfer || []);
      });
    },
    terminate() {
      rejectAllPendingWorkerCalls("Worker terminated.");
      worker.terminate();
    },
  };
}

async function createLocalBackend() {
  const wasmModule = await import("./pkg/ingestor_wasm.js");
  await wasmModule.default();
  const WasmIngestor = wasmModule.Ingestor;
  const WasmEmbedder = wasmModule.Embedder;
  let ingestor = null;
  let embedder = null;
  let embeddings = null; // Float32Array
  let embeddingsMeta = null; // { dim, count, modelId }
  let chunkMeta = null; // Array<{ id, ref, path, kind, start_line, end_line, heading_path, heading_joined, symbol, snippet }>
  let buildEmbeddingsPromise = null;

  function snippet(text, maxChars) {
    if (!text) return "";
    const cleaned = String(text).replace(/\s+/g, " ").trim();
    return cleaned.length > maxChars ? `${cleaned.slice(0, maxChars - 3)}...` : cleaned;
  }

  function passesFilters(chunk, filters) {
    if (!filters) return true;
    if (filters.path_exact && chunk.path !== filters.path_exact) return false;
    if (filters.path_prefix && !chunk.path.startsWith(filters.path_prefix)) return false;
    if (filters.kind && chunk.kind !== filters.kind) return false;
    if (filters.heading_prefix && !chunk.heading_joined.startsWith(filters.heading_prefix)) return false;
    if (filters.symbol_prefix) {
      if (!chunk.symbol) return false;
      if (!chunk.symbol.startsWith(filters.symbol_prefix)) return false;
    }
    return true;
  }

  function shouldUseEmbeddings() {
    if (!embeddings || !embeddingsMeta || !chunkMeta) return false;
    if (!embedder) return false;
    if (embeddingsMeta.modelId !== embedder.modelId()) return false;
    if (embeddingsMeta.count !== chunkMeta.length) return false;
    return true;
  }

  function dotProduct(a, b, bOffset, dim) {
    let sum = 0;
    for (let i = 0; i < dim; i += 1) {
      sum += a[i] * b[bOffset + i];
    }
    return sum;
  }

  function rrfFuse(bm25Results, semanticResults, limit) {
    const k = 60;
    const scores = new Map();

    function addList(results) {
      results.forEach((result, rank) => {
        const prev = scores.get(result.chunk_id) || 0;
        scores.set(result.chunk_id, prev + 1 / (k + rank + 1));
      });
    }

    addList(bm25Results);
    addList(semanticResults);

    return Array.from(scores.entries())
      .map(([chunkId, score]) => ({ chunkId, score }))
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  function buildSearchResult(meta, score) {
    return {
      chunk_id: meta.id,
      chunk_ref: meta.ref,
      score,
      path: meta.path,
      start_line: meta.start_line,
      end_line: meta.end_line,
      snippet: meta.snippet,
      heading_path: meta.heading_path,
    };
  }

  async function ensureEmbedder() {
    if (!embedder) {
      embedder = await WasmEmbedder.create();
    }
    return embedder;
  }

  async function buildEmbeddingsIndex() {
    if (!ingestor) {
      throw new Error("No index loaded");
    }
    const embed = await ensureEmbedder();
    const json = ingestor.exportIndexJson();
    const index = JSON.parse(json);

    const chunks = Array.isArray(index.chunks) ? index.chunks : [];
    const refs = index.chunk_refs || {};
    const dim = embed.dimension();
    const modelId = embed.modelId();

    chunkMeta = chunks.map((chunk) => {
      const headingPath = Array.isArray(chunk.heading_path) ? chunk.heading_path : [];
      const headingJoined = headingPath.join("/");
      return {
        id: chunk.id,
        ref: refs[chunk.id] || chunk.short_id || "",
        path: chunk.path || "",
        kind: chunk.kind || null,
        start_line: chunk.start_line || 0,
        end_line: chunk.end_line || 0,
        heading_path: headingPath,
        heading_joined: headingJoined,
        symbol: chunk.symbol || null,
        snippet: snippet(chunk.content || "", 200),
        content: chunk.content || "",
      };
    });

    const count = chunkMeta.length;
    const view = new Float32Array(count * dim);
    const batchSize = 8;

    for (let offset = 0; offset < count; offset += batchSize) {
      const batch = chunkMeta.slice(offset, offset + batchSize);
      const texts = batch.map((item) => item.content);
      const out = embed.embedBatch(texts);
      if (!out || typeof out.length !== "number") {
        throw new Error("Embedding batch returned unexpected type");
      }
      for (let i = 0; i < batch.length; i += 1) {
        const emb = out[i];
        if (!(emb instanceof Float32Array) || emb.length !== dim) {
          throw new Error("Embedding batch returned invalid vector");
        }
        view.set(emb, (offset + i) * dim);
      }

      await new Promise((resolve) => setTimeout(resolve, 0));
    }

    embeddings = view;
    embeddingsMeta = { dim, count, modelId };

    for (const meta of chunkMeta) {
      delete meta.content;
    }

    return embeddingsMeta;
  }

  return {
    kind: "local",
    async call(op, payload) {
      switch (op) {
        case "ping":
          return { ready: true };
        case "initEmbedder": {
          const embed = await ensureEmbedder();
          return { modelId: embed.modelId(), dimension: embed.dimension() };
        }
        case "ingest": {
          const files = (payload.files || []).map((file) => ({
            path: file.path,
            data: new Uint8Array(file.data),
            mtime_ms: file.mtime_ms ?? null,
            fingerprint_sha256: file.fingerprint_sha256 ?? null,
          }));
          ingestor = WasmIngestor.ingest(files, null);
          embeddings = null;
          embeddingsMeta = null;
          chunkMeta = null;
          buildEmbeddingsPromise = null;
          return { indexId: ingestor.indexId() };
        }
        case "updateSelective": {
          if (!ingestor) throw new Error("No index loaded");
          const files = (payload.files || []).map((file) => ({
            path: file.path,
            data: new Uint8Array(file.data),
            mtime_ms: file.mtime_ms ?? null,
            fingerprint_sha256: file.fingerprint_sha256 ?? null,
          }));
          await ingestor.updateSelective(files, payload.keepPaths || [], null);
          embeddings = null;
          embeddingsMeta = null;
          chunkMeta = null;
          buildEmbeddingsPromise = null;
          return { updated: true };
        }
        case "loadIndexJson":
          ingestor = WasmIngestor.fromIndexJson(payload.json);
          embeddings = null;
          embeddingsMeta = null;
          chunkMeta = null;
          buildEmbeddingsPromise = null;
          return { loaded: true };
        case "buildEmbeddings": {
          if (!buildEmbeddingsPromise) {
            buildEmbeddingsPromise = buildEmbeddingsIndex().finally(() => {
              buildEmbeddingsPromise = null;
            });
          }
          const meta = await buildEmbeddingsPromise;
          return { meta };
        }
        case "getEmbeddings": {
          if (!embeddings || !embeddingsMeta) {
            return { embeddings: null };
          }
          const buffer = embeddings.buffer.slice(0);
          return { embeddings: buffer, meta: embeddingsMeta };
        }
        case "setEmbeddings": {
          if (!ingestor) throw new Error("No index loaded");
          const { embeddings: buffer, meta } = payload || {};
          if (!(buffer instanceof ArrayBuffer)) {
            throw new Error("Embeddings payload must be an ArrayBuffer");
          }
          if (!meta || typeof meta.dim !== "number" || typeof meta.count !== "number") {
            throw new Error("Embeddings metadata missing");
          }
          const dim = meta.dim;
          const count = meta.count;
          if (dim <= 0 || count < 0) {
            throw new Error("Embeddings metadata invalid");
          }
          const view = new Float32Array(buffer);
          if (view.length !== dim * count) {
            throw new Error("Embeddings buffer length mismatch");
          }
          const json = ingestor.exportIndexJson();
          const index = JSON.parse(json);
          const chunks = Array.isArray(index.chunks) ? index.chunks : [];
          if (chunks.length !== count) {
            throw new Error("Embeddings count does not match index chunk count");
          }
          const refs = index.chunk_refs || {};
          chunkMeta = chunks.map((chunk) => {
            const headingPath = Array.isArray(chunk.heading_path) ? chunk.heading_path : [];
            const headingJoined = headingPath.join("/");
            return {
              id: chunk.id,
              ref: refs[chunk.id] || chunk.short_id || "",
              path: chunk.path || "",
              kind: chunk.kind || null,
              start_line: chunk.start_line || 0,
              end_line: chunk.end_line || 0,
              heading_path: headingPath,
              heading_joined: headingJoined,
              symbol: chunk.symbol || null,
              snippet: snippet(chunk.content || "", 200),
            };
          });
          embeddings = view;
          embeddingsMeta = meta;
          return { loaded: true };
        }
        case "exportIndexJson":
          if (!ingestor) throw new Error("No index loaded");
          return { json: ingestor.exportIndexJson() };
        case "stats":
          if (!ingestor) throw new Error("No index loaded");
          return { stats: await ingestor.stats() };
        case "warnings":
          if (!ingestor) throw new Error("No index loaded");
          return { warnings: await ingestor.warnings() };
        case "search":
          if (!ingestor) throw new Error("No index loaded");
          {
            const query = payload.query || "";
            const filters = payload.filters || null;
            const limit = payload.limit || 20;

            const bm25Results = await ingestor.search(query, filters, limit * 2);

            if (!embeddings || !embeddingsMeta || !chunkMeta) {
              return { results: bm25Results };
            }

            await ensureEmbedder();
            if (!shouldUseEmbeddings()) {
              return { results: bm25Results };
            }

            const queryEmbedding = embedder.embed(query);
            const dim = embeddingsMeta.dim;

            const semantic = [];
            for (let i = 0; i < chunkMeta.length; i += 1) {
              const meta = chunkMeta[i];
              if (!passesFilters(meta, filters)) continue;
              const score = dotProduct(queryEmbedding, embeddings, i * dim, dim);
              semantic.push({ idx: i, score });
            }

            semantic.sort((a, b) => b.score - a.score);
            const semanticTop = semantic.slice(0, limit * 2).map(({ idx, score }) => {
              const meta = chunkMeta[idx];
              return buildSearchResult(meta, score);
            });

            const merged = rrfFuse(bm25Results, semanticTop, limit);

            const bm25ById = new Map(bm25Results.map((r) => [r.chunk_id, r]));
            const results = merged.map(({ chunkId, score }) => {
              const existing = bm25ById.get(chunkId);
              if (existing) {
                return { ...existing, score };
              }
              const idx = chunkMeta.findIndex((m) => m.id === chunkId);
              if (idx !== -1) {
                return buildSearchResult(chunkMeta[idx], score);
              }
              return {
                chunk_id: chunkId,
                chunk_ref: "",
                score,
                path: "",
                start_line: 0,
                end_line: 0,
                snippet: "",
                heading_path: [],
              };
            });

            return { results };
          }
        case "getChunk":
          if (!ingestor) throw new Error("No index loaded");
          return { chunk: await ingestor.getChunk(payload.chunkId) };
        case "listOutline":
          if (!ingestor) throw new Error("No index loaded");
          return { outline: await ingestor.listOutline(payload.path) };
        case "listSymbols":
          if (!ingestor) throw new Error("No index loaded");
          return { symbols: await ingestor.listSymbols(payload.path) };
        case "exportLlm":
          if (!ingestor) throw new Error("No index loaded");
          return { content: ingestor.exportLlm() };
        case "exportLlmPointer":
          if (!ingestor) throw new Error("No index loaded");
          return { content: ingestor.exportLlmPointer() };
        case "exportOutline":
          if (!ingestor) throw new Error("No index loaded");
          return { content: ingestor.exportLlm() };
        case "exportZip":
          if (!ingestor) throw new Error("No index loaded");
          return { bytes: ingestor.exportZip() };
        case "exportZipCompact":
          if (!ingestor) throw new Error("No index loaded");
          return { bytes: ingestor.exportZipCompact() };
        case "files":
          if (!ingestor) throw new Error("No index loaded");
          return { files: await ingestor.files() };
        case "indexId":
          if (!ingestor) throw new Error("No index loaded");
          return { indexId: ingestor.indexId() };
        default:
          throw new Error(`Unknown op: ${op}`);
      }
    },
    terminate() {},
  };
}

async function initWorker() {
  let initError = null;

  try {
    state.backend = createWorkerBackend();
    const result = await callWorker("ping", {});
    if (!result.ready) {
      throw new Error("Worker did not initialize");
    }
    state.workerReady = true;
    setStatus("Ready for ingestion.");
    await populateSavedIndexes();
    return;
  } catch (error) {
    initError = error;
    try {
      state.backend?.terminate?.();
    } catch {}
    state.backend = null;
  }

  const local = await createLocalBackend();
  const result = await local.call("ping", {});
  if (!result.ready) {
    throw new Error("WASM did not initialize");
  }
  state.backend = local;
  state.workerReady = true;
  const reason = initError ? ` (${formatErrorForUi(initError)})` : "";
  setStatus(`Ready for ingestion (worker disabled)${reason}.`);
  await populateSavedIndexes();
}

if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", () => {
    if (state.backend) {
      state.backend.terminate();
    }
  });
}

function isAllowedPath(path) {
  const lower = path.toLowerCase();
  if (SKIP_DIRS.some((dir) => lower.includes(`/${dir}/`) || lower.startsWith(`${dir}/`))) {
    return false;
  }
  return ALLOWED_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

async function collectFilesFromInput(fileList) {
  const entries = [];
  let totalBytes = 0;
  let skippedLarge = 0;
  let skippedTotal = 0;
  let skippedCount = 0;
  for (const file of fileList) {
    const path = file.webkitRelativePath || file.name;
    if (!isAllowedPath(path)) {
      continue;
    }
    if (entries.length >= DEFAULT_LIMITS.maxFileCount) {
      skippedCount += 1;
      continue;
    }
    if (file.size > DEFAULT_LIMITS.maxFileBytes) {
      skippedLarge += 1;
      continue;
    }
    if (totalBytes + file.size > DEFAULT_LIMITS.maxTotalBytes) {
      skippedTotal += 1;
      continue;
    }
    entries.push({ path, file });
    totalBytes += file.size;
  }
  return { entries, skippedLarge, skippedTotal, skippedCount, totalBytes };
}

async function collectFilesFromHandle(handle, basePath = "", budget = null) {
  const entries = [];
  const shared = budget || {
    totalBytes: 0,
    fileCount: 0,
    skippedLarge: 0,
    skippedTotal: 0,
    skippedCount: 0,
  };
  for await (const [name, entry] of handle.entries()) {
    if (entry.kind === "directory") {
      if (SKIP_DIRS.includes(name)) {
        continue;
      }
      const nested = await collectFilesFromHandle(entry, `${basePath}${name}/`, shared);
      entries.push(...nested.entries);
      continue;
    }
    const path = `${basePath}${name}`;
    if (!isAllowedPath(path)) {
      continue;
    }
    if (shared.fileCount >= DEFAULT_LIMITS.maxFileCount) {
      shared.skippedCount += 1;
      continue;
    }
    const file = await entry.getFile();
    if (file.size > DEFAULT_LIMITS.maxFileBytes) {
      shared.skippedLarge += 1;
      continue;
    }
    if (shared.totalBytes + file.size > DEFAULT_LIMITS.maxTotalBytes) {
      shared.skippedTotal += 1;
      continue;
    }
    entries.push({ path, file });
    shared.totalBytes += file.size;
    shared.fileCount += 1;
  }
  return {
    entries,
    skippedLarge: shared.skippedLarge,
    skippedTotal: shared.skippedTotal,
    skippedCount: shared.skippedCount,
    totalBytes: shared.totalBytes
  };
}

function isImagePath(path) {
  const lower = path.toLowerCase();
  return (
    lower.endsWith(".png") ||
    lower.endsWith(".jpg") ||
    lower.endsWith(".jpeg") ||
    lower.endsWith(".webp") ||
    lower.endsWith(".gif") ||
    lower.endsWith(".bmp")
  );
}

function hexEncode(bytes) {
  let out = "";
  for (const b of bytes) {
    out += b.toString(16).padStart(2, "0");
  }
  return out;
}

async function sha256Hex(data) {
  const buffer = data instanceof ArrayBuffer ? data : data.buffer;
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return hexEncode(new Uint8Array(digest));
}

async function fingerprintFile(file) {
  const size = file.size;
  const headLen = 4096;
  const tailLen = 4096;
  if (size <= headLen + tailLen) {
    const full = await file.arrayBuffer();
    return sha256Hex(full);
  }
  const head = await file.slice(0, headLen).arrayBuffer();
  const tail = await file.slice(size - tailLen, size).arrayBuffer();

  const sizeBytes = new Uint8Array(8);
  const view = new DataView(sizeBytes.buffer);
  view.setBigUint64(0, BigInt(size), true);

  const combined = new Uint8Array(sizeBytes.byteLength + head.byteLength + tail.byteLength);
  combined.set(sizeBytes, 0);
  combined.set(new Uint8Array(head), sizeBytes.byteLength);
  combined.set(new Uint8Array(tail), sizeBytes.byteLength + head.byteLength);
  return sha256Hex(combined);
}

async function runIngest(entries, collectedMeta) {
  if (!state.workerReady) {
    setStatus("Backend not ready.");
    return;
  }
  if (!entries.length) {
    setStatus(`No supported files found. Accepted: ${ALLOWED_EXTENSIONS.join(", ")}`);
    return;
  }
  const skippedLarge = collectedMeta?.skippedLarge || 0;
  const skippedTotal = collectedMeta?.skippedTotal || 0;
  const skippedCount = collectedMeta?.skippedCount || 0;
  const totalBytes = collectedMeta?.totalBytes || 0;
  const skippedNote =
    skippedLarge || skippedTotal || skippedCount
      ? ` (skipped: ${skippedLarge} too large, ${skippedTotal} over total limit, ${skippedCount} too many files)`
      : "";

  // Warn if approaching limits
  if (totalBytes > DEFAULT_LIMITS.warnTotalBytes) {
    console.warn(`Large upload: ${(totalBytes / 1024 / 1024).toFixed(1)}MB. Browser may slow down.`);
  }
  if (entries.length > DEFAULT_LIMITS.maxFileCount * 0.8) {
    console.warn(`Many files: ${entries.length}. Processing may take time.`);
  }

  const prevByPath = new Map((state.files || []).map((meta) => [meta.path, meta]));
  const currentPaths = new Set(entries.map((e) => e.path));
  let removedCount = 0;
  if (state.indexLoaded) {
    for (const path of prevByPath.keys()) {
      if (!currentPaths.has(path)) {
        removedCount += 1;
      }
    }
  }

  try {
    state.busy = true;

    if (!state.indexLoaded) {
      setStatus(`Ingesting ${entries.length} files${skippedNote}...`);
      const files = [];
      for (let i = 0; i < entries.length; i++) {
        const entry = entries[i];
        const data = await entry.file.arrayBuffer();
        files.push({
          path: entry.path,
          data,
          mtime_ms: Number.isFinite(entry.file.lastModified) ? entry.file.lastModified : null,
          fingerprint_sha256: null,
        });
        // Yield to browser every 10 files to prevent freezing
        if (i % 10 === 0 && i > 0) {
          setStatus(`Ingesting ${entries.length} files (${i}/${entries.length})${skippedNote}...`);
          await new Promise(resolve => setTimeout(resolve, 0));
        }
      }
      const transfer = files.map((f) => f.data);
      await callWorker("ingest", { files }, state.backend?.kind === "worker" ? transfer : undefined);
    } else {
      let unchanged = 0;
      let changed = 0;
      let added = 0;
      const keepPaths = [];
      const files = [];

      for (const entry of entries) {
        const prev = prevByPath.get(entry.path);
        const isImage = isImagePath(entry.path);
        if (!prev) {
          added += 1;
          const data = await entry.file.arrayBuffer();
          files.push({
            path: entry.path,
            data,
            mtime_ms: Number.isFinite(entry.file.lastModified) ? entry.file.lastModified : null,
            fingerprint_sha256: await fingerprintFile(entry.file),
          });
          continue;
        }

        if (isImage) {
          // Always include image bytes so `export.zip` always contains the assets.
          const data = await entry.file.arrayBuffer();
          files.push({
            path: entry.path,
            data,
            mtime_ms: Number.isFinite(entry.file.lastModified) ? entry.file.lastModified : null,
            fingerprint_sha256: prev.fingerprint_sha256 || (await fingerprintFile(entry.file)),
          });
          continue;
        }

        const prevBytes = prev.bytes ?? null;
        if (prevBytes !== null && prevBytes !== entry.file.size) {
          changed += 1;
          const data = await entry.file.arrayBuffer();
          files.push({
            path: entry.path,
            data,
            mtime_ms: Number.isFinite(entry.file.lastModified) ? entry.file.lastModified : null,
            fingerprint_sha256: await fingerprintFile(entry.file),
          });
          continue;
        }

        const prevFp = prev.fingerprint_sha256 || null;
        if (prevFp) {
          const fp = await fingerprintFile(entry.file);
          if (fp === prevFp) {
            unchanged += 1;
            keepPaths.push(entry.path);
          } else {
            changed += 1;
            const data = await entry.file.arrayBuffer();
            files.push({
              path: entry.path,
              data,
              mtime_ms: Number.isFinite(entry.file.lastModified) ? entry.file.lastModified : null,
              fingerprint_sha256: fp,
            });
          }
          continue;
        }

        // Fallback: if we don't have a fingerprint in the cache yet, be conservative and re-read once.
        changed += 1;
        const data = await entry.file.arrayBuffer();
        files.push({
          path: entry.path,
          data,
          mtime_ms: Number.isFinite(entry.file.lastModified) ? entry.file.lastModified : null,
          fingerprint_sha256: await fingerprintFile(entry.file),
        });
      }

      setStatus(
        `Updating index: ${unchanged} unchanged, ${changed} changed, ${added} new, ${removedCount} removed${skippedNote}...`
      );
      const transfer = files.map((f) => f.data);
      await callWorker(
        "updateSelective",
        { files, keepPaths },
        state.backend?.kind === "worker" ? transfer : undefined
      );
    }

    const statsResult = await callWorker("stats", {});
    const warningsResult = await callWorker("warnings", {});
    const filesResult = await callWorker("files", {});

    const idResult = await callWorker("indexId", {});
    state.indexId = idResult.indexId || null;
    state.files = filesResult.files || [];

    elements.indexId.textContent = state.indexId || "(unknown)";
    elements.chunkCount.textContent = statsResult.stats.total_chunks;
    elements.warningCount.textContent = warningsResult.warnings.length;
    renderWarnings(warningsResult.warnings);
    populateFileFilter();
    await updateOutlineSymbols();
    await populateSavedIndexes();
    state.indexLoaded = true;
    setStatus("Index ready.");
    if (embeddingsRequested) {
      void callWorker("buildEmbeddings", {}).catch(() => {});
    }
  } catch (error) {
    setStatus(`Ingestion failed: ${formatErrorForUi(error)}`);
  } finally {
    state.busy = false;
  }
}

function renderWarnings(warnings) {
  elements.warningList.replaceChildren();
  if (!warnings.length) {
    return;
  }
  for (const warning of warnings) {
    const div = document.createElement("div");
    div.textContent = `${warning.path}: ${warning.message}`;
    elements.warningList.appendChild(div);
  }
}

elements.selectFolder.addEventListener("click", async () => {
  const supportsDirectoryPicker = typeof window.showDirectoryPicker === "function";
  const supportsWebkitDirectory = elements.folderInput && "webkitdirectory" in elements.folderInput;

  if (supportsDirectoryPicker) {
    try {
      const handle = await window.showDirectoryPicker();
      const collected = await collectFilesFromHandle(handle);
      await runIngest(collected.entries, collected);
      return;
    } catch (error) {
      setStatus("Folder selection cancelled.");
      return;
    }
  }

  if (supportsWebkitDirectory) {
    elements.folderInput.click();
    return;
  }

  setStatus("Folder selection is not supported in this browser. Use Select files or drag-and-drop.");
});

elements.selectFiles.addEventListener("click", () => {
  elements.filesInput.click();
});

elements.folderInput.addEventListener("change", async (event) => {
  const collected = await collectFilesFromInput(event.target.files || []);
  await runIngest(collected.entries, collected);
});

elements.filesInput.addEventListener("change", async (event) => {
  const collected = await collectFilesFromInput(event.target.files || []);
  await runIngest(collected.entries, collected);
});

elements.dropZone.addEventListener("dragover", (event) => {
  event.preventDefault();
  elements.dropZone.classList.add("active");
});

elements.dropZone.addEventListener("dragleave", () => {
  elements.dropZone.classList.remove("active");
});

elements.dropZone.addEventListener("drop", async (event) => {
  event.preventDefault();
  elements.dropZone.classList.remove("active");
  const collected = await collectFilesFromInput(event.dataTransfer.files || []);
  await runIngest(collected.entries, collected);
});

elements.fileFilter.addEventListener("change", async () => {
  await updateOutlineSymbols();
  scheduleSearch();
});

elements.runSearch.addEventListener("click", async () => {
  await runSearch();
});

elements.query.addEventListener("keydown", async (event) => {
  if (event.key === "Enter") {
    await runSearch();
  }
});

elements.query.addEventListener("input", () => {
  scheduleSearch();
});

elements.pathFilter.addEventListener("input", () => {
  scheduleSearch();
});

elements.kindFilter.addEventListener("change", () => {
  scheduleSearch();
});

elements.outlineFilter.addEventListener("change", () => {
  scheduleSearch();
});

elements.symbolFilter.addEventListener("change", () => {
  scheduleSearch();
});

elements.closeChunk.addEventListener("click", () => {
  elements.chunkView.hidden = true;
});

elements.exportLlmPointer.addEventListener("click", () => {
  if (!state.indexLoaded) {
    setStatus("No index to export.");
    return;
  }
  callWorker("exportLlmPointer", {})
    .then(({ content }) => {
      downloadFile("llm.md", content, "text/markdown");
    })
    .catch(() => setStatus("Export failed."));
});

elements.exportCatalogLlm.addEventListener("click", () => {
  if (!state.indexLoaded) {
    setStatus("No index to export.");
    return;
  }
  callWorker("exportCatalogLlmMd", {})
    .then(({ content }) => {
      downloadFile("catalog.llm.md", content, "text/markdown");
    })
    .catch(() => setStatus("Export failed."));
});

elements.exportManifestLlmTsv.addEventListener("click", () => {
  if (!state.indexLoaded) {
    setStatus("No index to export.");
    return;
  }
  callWorker("exportManifestLlmTsv", {})
    .then(({ content }) => {
      downloadFile("manifest.llm.tsv", content, "text/tab-separated-values");
    })
    .catch(() => setStatus("Export failed."));
});

elements.exportLlmOutline.addEventListener("click", () => {
  if (!state.indexLoaded) {
    setStatus("No index to export.");
    return;
  }
  callWorker("exportOutline", {})
    .then(({ content }) => {
      downloadFile("outline.md", content, "text/markdown");
    })
    .catch(() => setStatus("Export failed."));
});

elements.exportZipCompact.addEventListener("click", () => {
  if (!state.indexLoaded) {
    setStatus("No index to export.");
    return;
  }
  callWorker("exportZipCompact", {})
    .then(({ bytes }) => {
      downloadFile("export.compact.zip", bytes, "application/zip");
    })
    .catch(() => setStatus("Export failed."));
});

elements.exportZip.addEventListener("click", () => {
  if (!state.indexLoaded) {
    setStatus("No index to export.");
    return;
  }
  callWorker("exportZip", {})
    .then(({ bytes }) => {
      downloadFile("export.full.zip", bytes, "application/zip");
    })
    .catch(() => setStatus("Export failed."));
});

elements.saveIndex.addEventListener("click", async () => {
  if (!state.indexLoaded) {
    setStatus("No index to save.");
    return;
  }
  try {
    const { json } = await callWorker("exportIndexJson", {});
    let embeddings = null;
    let embeddingsMeta = null;
    try {
      const result = await callWorker("getEmbeddings", {});
      if (result.embeddings && result.meta) {
        embeddings = result.embeddings;
        embeddingsMeta = result.meta;
      }
    } catch {}
    await saveIndex(state.indexId || "index", json, embeddings, embeddingsMeta);
    await populateSavedIndexes();
    setStatus("Index saved locally.");
  } catch {
    setStatus("Index save failed.");
  }
});

async function runSearch() {
  if (!state.indexLoaded) {
    setStatus("No index loaded.");
    return;
  }
  const query = elements.query.value.trim();
  if (!query) {
    elements.results.replaceChildren();
    elements.chunkView.hidden = true;
    setStatus("Index ready.");
    return;
  }
  const filters = {
    path_exact: elements.fileFilter.value || null,
    path_prefix: elements.fileFilter.value ? null : selectPathPrefix(),
    kind: elements.kindFilter.value || null,
    heading_prefix: elements.outlineFilter.value || null,
    symbol_prefix: elements.symbolFilter.value || null,
  };
  const seq = ++state.searchSeq;
  elements.runSearch.disabled = true;
  setStatus("Searching...");
  try {
    const { results } = await callWorker("search", { query, filters, limit: 20 });
    if (seq !== state.searchSeq) {
      return;
    }
    renderResults(results);
    setStatus(`Found ${results.length} results.`);
  } catch (error) {
    if (seq === state.searchSeq) {
      setStatus("Search failed.");
    }
  } finally {
    if (seq === state.searchSeq) {
      elements.runSearch.disabled = false;
    }
  }
}

function renderResults(results) {
  elements.results.replaceChildren();
  if (!results.length) {
    const empty = document.createElement("div");
    empty.textContent = "No matches.";
    elements.results.appendChild(empty);
    return;
  }
  for (const result of results) {
    const item = document.createElement("div");
    item.className = "result-item";

    const title = document.createElement("strong");
    title.textContent = result.path;

    const meta = document.createElement("div");
    meta.className = "meta";
    const heading = result.heading_path.length ? ` | ${result.heading_path.join("/")}` : "";
    const ref = result.chunk_ref ? ` | ${result.chunk_ref}` : "";
    meta.textContent = `Lines ${result.start_line}-${result.end_line}${ref}${heading}`;

    const snippet = document.createElement("div");
    snippet.textContent = result.snippet;

    const button = document.createElement("button");
    button.textContent = "View chunk";
    button.addEventListener("click", async () => {
      const { chunk } = await callWorker("getChunk", { chunkId: result.chunk_id });
      if (!chunk) {
        return;
      }
      const ref = chunk.short_id ? ` | Ref: ${chunk.short_id}` : "";
      const label = chunk.slug ? ` | ${chunk.slug}` : "";
      elements.chunkTitle.textContent = `${chunk.path} (${chunk.start_line}-${chunk.end_line})${ref}${label}`;
      elements.chunkContent.textContent = chunk.content;
      elements.chunkView.hidden = false;
    });

    item.appendChild(title);
    item.appendChild(meta);
    item.appendChild(snippet);
    item.appendChild(button);
    elements.results.appendChild(item);
  }
}

function downloadFile(name, content, type) {
  let blob;
  if (content instanceof Uint8Array || Array.isArray(content)) {
    blob = new Blob([content], { type });
  } else {
    blob = new Blob([content], { type });
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

function populateFileFilter() {
  elements.fileFilter.replaceChildren();
  const option = document.createElement("option");
  option.value = "";
  option.textContent = "All files";
  elements.fileFilter.appendChild(option);
  for (const file of state.files || []) {
    const item = document.createElement("option");
    item.value = file.path;
    item.textContent = file.path;
    elements.fileFilter.appendChild(item);
  }
}

async function updateOutlineSymbols() {
  elements.outlineFilter.replaceChildren();
  elements.symbolFilter.replaceChildren();
  const outlineOption = document.createElement("option");
  outlineOption.value = "";
  outlineOption.textContent = "All outlines";
  elements.outlineFilter.appendChild(outlineOption);
  const symbolOption = document.createElement("option");
  symbolOption.value = "";
  symbolOption.textContent = "All symbols";
  elements.symbolFilter.appendChild(symbolOption);
  const path = elements.fileFilter.value;
  if (!state.indexLoaded || !path) {
    return;
  }
  try {
    const { outline: outlines } = await callWorker("listOutline", { path });
    const { symbols } = await callWorker("listSymbols", { path });
    for (const outline of outlines) {
      const option = document.createElement("option");
      option.value = outline;
      option.textContent = outline;
      elements.outlineFilter.appendChild(option);
    }
    for (const symbol of symbols) {
      const option = document.createElement("option");
      option.value = symbol;
      option.textContent = symbol;
      elements.symbolFilter.appendChild(option);
    }
  } catch (error) {
    setStatus("Outline/symbol lookup failed.");
  }
}

function selectPathPrefix() {
  if (elements.fileFilter.value) {
    return elements.fileFilter.value;
  }
  const manual = elements.pathFilter.value.trim();
  return manual || null;
}

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("llmx-ingestor", 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("indexes")) {
        db.createObjectStore("indexes", { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

let searchTimer = null;
function scheduleSearch() {
  if (!state.indexLoaded || state.busy) {
    return;
  }
  if (searchTimer) {
    clearTimeout(searchTimer);
  }
  searchTimer = setTimeout(async () => {
    searchTimer = null;
    await runSearch();
  }, 200);
}

async function saveIndex(id, json, embeddings, embeddingsMeta) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("indexes", "readwrite");
    tx.objectStore("indexes").put({
      id,
      json,
      embeddings: embeddings || null,
      embeddings_meta: embeddingsMeta || null,
      saved_at: new Date().toISOString(),
    });
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function listIndexes() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("indexes", "readonly");
    const request = tx.objectStore("indexes").getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

async function deleteIndex(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("indexes", "readwrite");
    tx.objectStore("indexes").delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function populateSavedIndexes() {
  if (!elements.savedIndexes) {
    return;
  }
  const records = await listIndexes();
  records.sort((a, b) => (b.saved_at || "").localeCompare(a.saved_at || ""));
  elements.savedIndexes.replaceChildren();
  const empty = document.createElement("option");
  empty.value = "";
  empty.textContent = records.length ? "Select saved index" : "No saved indexes";
  elements.savedIndexes.appendChild(empty);
  for (const record of records) {
    const option = document.createElement("option");
    option.value = record.id;
    option.textContent = `${record.id} (${record.saved_at || "unknown"})`;
    elements.savedIndexes.appendChild(option);
  }
}

elements.loadSavedIndex?.addEventListener("click", async () => {
  const id = elements.savedIndexes.value;
  if (!id) {
    return;
  }
  const records = await listIndexes();
  const record = records.find((r) => r.id === id);
  if (!record) {
    setStatus("Saved index not found.");
    return;
  }
  try {
    state.busy = true;
    await callWorker("loadIndexJson", { json: record.json });
    if (record.embeddings && record.embeddings_meta) {
      try {
        await callWorker(
          "setEmbeddings",
          { embeddings: record.embeddings, meta: record.embeddings_meta },
          state.backend?.kind === "worker" ? [record.embeddings] : undefined
        );
      } catch {}
    }
    const idResult = await callWorker("indexId", {});
    const statsResult = await callWorker("stats", {});
    const warningsResult = await callWorker("warnings", {});
    const filesResult = await callWorker("files", {});
    state.indexId = idResult.indexId || null;
    state.files = filesResult.files || [];
    state.indexLoaded = true;
    elements.indexId.textContent = state.indexId || "(unknown)";
    elements.chunkCount.textContent = statsResult.stats.total_chunks;
    elements.warningCount.textContent = warningsResult.warnings.length;
    renderWarnings(warningsResult.warnings);
    populateFileFilter();
    await updateOutlineSymbols();
    setStatus("Loaded saved index.");
    if (embeddingsRequested) {
      void callWorker("buildEmbeddings", {}).catch(() => {});
    }
  } catch {
    setStatus("Failed to load saved index.");
  } finally {
    state.busy = false;
  }
});

elements.deleteSavedIndex?.addEventListener("click", async () => {
  const id = elements.savedIndexes.value;
  if (!id) {
    return;
  }
  try {
    await deleteIndex(id);
    await populateSavedIndexes();
    setStatus("Deleted saved index.");
  } catch {
    setStatus("Failed to delete saved index.");
  }
});

configureFolderPickerUi();
initWorker().catch((error) => {
  setStatus(`Failed to start backend: ${formatErrorForUi(error)}`);
});
